<?php
// config_all.php
// To create a database named: work and 
// create table named: employee

$con = mysql_connect ("localhost","root","");
if (!$con)
  {
  die ('Could not connect: ' . mysql_error());
  }
$query  = 'CREATE DATABASE work';
$result = mysql_query($query);

mysql_select_db('work') or die('Cannot select database'); 

$query = 'CREATE TABLE employee( '.
         'id INT NOT NULL AUTO_INCREMENT, '.
         'name VARCHAR(50) NOT NULL, '.
         'address VARCHAR(50) NOT NULL, '.
         'city VARCHAR(50) NOT NULL, '.
         'PRIMARY KEY(id))';

$result = mysql_query($query);

mysql_close($con);
echo "<center> <font color='blue' size='16'> <br><br>";
echo " Your  Database and Table Has been Created !!! ";
echo "</font> </center>";

?>
