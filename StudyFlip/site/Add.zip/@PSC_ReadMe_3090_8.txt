Title: Persons Information System
Description: A simple Personnel Information System that has a function to add,edit and delete records in the database. I also included a script to create database and tables so that the programmer will no longer require to make a database and table in the phpmyadmin. In addition I also included SQL dump file to create the records in the table and sample records in the database.
 I hope this program will help PHP/MySQL programmers, developers like me. If you like my work please send me an email at jakerpomperada@yahoo.com  and jakerpomperada@gmail.com. Here in the Philippines people can reach me through my mobile numbers 09993969756, 09154628025 and 09288471599. 
 I am also working as a freelance developer if you like to acquire my programming services kindly contact me in my  email address above and mobile phone numbers. Thank you very much and Happy Programming. 
 Regards, Mr. Jake Rodriguez Pomperada, MAED-IT Teacher, Software Developer, Web Developer and Electronics and Computer Technician 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3090&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
