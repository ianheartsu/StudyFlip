<!-- index.php -->
<!-- Created By: Mr. Jake Rodriguez Pomperada, MAED-IT -->
<html>
<head>
<title>View Records</title>
</head>
<br>
<font color='blue' name='arial' size='10'>
<center>
Persons Information System </center>
</font>
<body>
<?php

include('config.php');

$result = mysql_query("SELECT * FROM employee")
or die(mysql_error());

echo "<table border='1' cellpadding='10'>";
echo "<tr>
<th><font color='Red' name='arial'>Id</font></th>
<th><font color='Red' name='arial'>Name</font></th>
<th><font color='Red' name='arial'>Address</font></th>
<th><font color='Red' name='arial'>City</font></th>
<th><font color='Red' name='arial'>Edit</font></th>
<th><font color='Red' name='arial'>Delete</font></th>
</tr>";

while($row = mysql_fetch_array( $result ))
{

echo "<tr>";
echo '<td><b><font color="#663300" name="arial">' . $row['id'] . '</font></b></td>';
echo '<td><b><font color="#663300" name="arial">' . $row['name'] . '</font></b></td>';
echo '<td><b><font color="#663300" name="arial">' . $row['address'] . '</font></b></td>';
echo '<td><b><font color="#663300" name="arial">' . $row['city'] . '</font></b></td>';
echo '<td><b><font color="#663300" name="arial"><a href="edit.php?id=' . $row['id'] . '">Edit</a></font></b></td>';
echo '<td><b><font color="#663300" name="arial"><a href="delete.php?id=' . $row['id'] . '">Delete</a></font></b></td>';
echo "</tr>";

}

echo "</table>";
?>
<font color="blue" name="arial" size=5>
<p><a href="insert.php"
 title="Click here to add new record in the database">
 Add New Record</a></p> </font>
</body>
</html>