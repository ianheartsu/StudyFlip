<?php
 function valid($name, $address,$city, $error)
 {
 ?>
<!-- insert.php -->
<!-- Created By: Mr. Jake Rodriguez Pomperada, MAED-IT -->
 <html>
 <head>
 <title>Add Records</title>
 </head>
 <body>
 <?php

 if ($error != '')
 {
 echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';
 }
 ?>
 <br>
<font color='blue' name='arial' size='10'>
<center>
Persons Information System </center>
</font>

 <form action="" method="post">
 <table border="1">
     <tr>
       <td colspan="2"><b><font color='Red'>Add Records </font></b></td>
       </tr>
  <tr>
      <td width="179"><b><font color='#663300'>Name<em>*</em></font></b></td>
      <td><label>
       <input type="text" name="name"  size="50" value="<?php echo $name; ?>" />
      </label></td>
    </tr>

    <tr>
        <td width="179"><b><font color='#663300'>Address<em>*</em></font></b></td>
        <td><label>
         <input type="text" name="address" size="50" value="<?php echo $address; ?>" />
        </label></td>
    </tr>

    <tr>
        <td width="179"><b><font color='#663300'>City<em>*</em></font></b></td>
        <td><label>
         <input type="text" name="city" size="50" value="<?php echo $city; ?>" />
        </label></td>
    </tr>

    <tr align="Right">
        <td colspan="2"><label>
           <input type="submit" name="submit" value="Insert Records">
        </label></td>
        </tr>
</table>
 </form>
 </body>
 </html>
 <?php
 }


 include('config.php');

 if (isset($_POST['submit']))
 {

 $name = mysql_real_escape_string(htmlspecialchars($_POST['name']));
 $address = mysql_real_escape_string(htmlspecialchars($_POST['address']));
 $city = mysql_real_escape_string(htmlspecialchars($_POST['city']));

 if ($name == '' || $address == '' || $city == '')
 {

 $error = 'Please enter the details!';

 valid($name, $address, $city,$error);
 }
 else
 {

 mysql_query("INSERT employee SET name='$name', address='$address', city='$city'")
 or die(mysql_error());

 header("Location: index.php");
 }
 }
 else
 {
 valid('','','','');
 }
?>