<html>
    <head>
        <title>Search the Database</title>
    </head>
     <center>
      <h2>	  
	  <br> 
	  SEARCH A RECORD 1.0
	  <br> 
       </h2>
	 <h3>	
	Created By: Mr. Jake Rodriguez Pomperada, MAED - IT
	  </h3> </center>
	  
    <body>
    <br> 
       <form method="post" action="" name="form1" id="form1" >   
   
     Type the First Name, Last Name or ID Number of the User
	 <br><br>
	 <b>Search Record  </b> <input type="text" name="term" /><br />
	 <br>
    <input type="submit" name="submit" value="Search" />
    </form>
	
	<h3> <center> List of Record (s) </h3> </center>
 <?php
if ($_REQUEST['submit']) {
 $connection = mysql_connect ("localhost", "root","123")  or die (mysql_error());
mysql_select_db ("users");
 
$term = $_POST['term'];
 
$XX = "<br><br><h2> <center> No Record Found, Search Again Please </center> </h2>";  
 
 $sql = mysql_query("select * from information where firstname like '%$term%'
                     or lastname like '%$term%'  or ID like '%$term%' ")
   or die('Error in query : $sql. ' .mysql_error());
   
if (mysql_num_rows($sql) > 0) 
{            
 
while ($row = mysql_fetch_array($sql)){
    
    echo '<h4>  ID                  :  '.$row['ID'] ;
    echo '<br>  First Name          :  '.$row['firstname'];
    echo '<br>  Last Name           :  '.$row['lastname'];
	echo '<br>  Email Address       :  '.$row['email'];
    echo '<br>  Telephone Number    :  '.$row['phonenumber'];
    echo ' </h4>';
	
  
	}
} 		 
else
 {
print ("$XX");
}
mysql_free_result($sql);
mysql_close($connection);
}
?>
 

    </body>
</html>