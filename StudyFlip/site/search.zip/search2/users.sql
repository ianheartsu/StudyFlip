-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2011 at 11:54 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE IF NOT EXISTS `information` (
  `ID` int(3) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phonenumber` varchar(15) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`ID`, `firstname`, `lastname`, `email`, `phonenumber`) VALUES
(1, 'Jake', 'Pomperada', 'jakerpomperada@yahoo.com', '433-50-81'),
(2, 'Leslie Vinky', 'Pepito', 'leslievinky@yahoo.com', '433-50-81'),
(3, 'Ma. Junnalie', 'Fuentebella', 'allie@gmail.com', '433-56-75'),
(4, 'Wayne Custer', 'Alegata', 'wayne@yahoo.com', '444-25-15'),
(5, 'Albert', 'Pepito', 'albert@timex.com', '433-50-81'),
(6, 'Mamerto', 'Logronio Jr.', 'mamert@hotmail.com', '455-26-78'),
(7, 'Carnit George', 'Cordova', 'kooks_cordova@yahoo.com.ph', '423-56-87'),
(8, 'Siegfred', 'Tan', 'batman@gmail.com', '452-56-34'),
(9, 'Rollyn', 'Moises', 'rollyn@programmer.net', '707-23-45'),
(10, 'Mark', 'Pahilanga', 'mark@easymail.com', '534-12-23');
