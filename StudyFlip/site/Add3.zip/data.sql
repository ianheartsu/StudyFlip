-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 08, 2011 at 12:49 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `class`
--

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `lid` int(5) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`lid`, `address`) VALUES
(1, 'Purok Pag-asa, Barangay Alijis Bacolod City 6100, Negros Occidental'),
(2, 'Victoria - Malaga, Eroreco Subdivision, Bacolod City 6100, Negros Occidental'),
(3, 'Michigan, United States of America'),
(4, 'Riyadh Kingdom of Saudi Arabia'),
(5, 'Estaca Compostela, Cebu City'),
(7, 'Calamba, Laguna'),
(9, 'Los Angeles California, United States of America'),
(10, 'Los Angeles California, United States of America'),
(14, 'Murcia, Negros Occidental'),
(18, 'Shooping Street, Bacolod City'),
(19, 'Boston Massachusettes, United States of America');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE IF NOT EXISTS `school` (
  `sid` int(5) NOT NULL,
  `sname` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`sid`, `sname`) VALUES
(1, 'UNO-R'),
(2, 'UNO-R'),
(3, 'USLS'),
(4, 'Riverside College'),
(5, 'CIT Cebu'),
(7, 'UST'),
(9, 'UCLA'),
(10, 'CHMSC Alijis Campus'),
(14, 'UNO-R'),
(19, 'Boston State Univeristy'),
(18, 'CSA-B');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `course`) VALUES
(1, 'Jake Pomperada', 'BS Computer Science'),
(2, 'Ma. Junallie Fuentebella', 'BS Chemical Engineering'),
(3, 'Leslie Vinky Pepito', 'BS ECE'),
(4, 'Paul Jun Noblezada', 'BS Physical Therapist'),
(5, 'Albert Pepito', 'BS Information Technology'),
(7, 'Jose Rizal', 'BS Biology'),
(9, 'Kobe Bryant', 'BS Business Management'),
(10, 'Maria Resley', 'BS Computer Technology'),
(14, 'Jose Mendoza', 'BS Accountancy'),
(19, 'Larry Bird', 'BS Mathematics'),
(18, 'Ana Tan', 'BS Management');

-- --------------------------------------------------------

--
-- Table structure for table `work`
--

CREATE TABLE IF NOT EXISTS `work` (
  `wid` int(5) NOT NULL,
  `work` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `work`
--

INSERT INTO `work` (`wid`, `work`) VALUES
(1, 'Freelance Programmer,Web Developer and Computer/Electronics Technician'),
(2, 'Chemical Engineer / Assistant Professor'),
(3, 'Electronics Engineer / Software Test Engineer'),
(4, 'Physical Therapist / Registered Nurse'),
(5, 'Software Engineer/ Database Administrator'),
(7, 'Medical Doctor'),
(9, 'Professional Basketball Player'),
(10, 'Care Giver and Nursing Aide'),
(14, 'Office Manager'),
(18, 'Sales Girl'),
(19, 'Professional Basketball Player / High School Math Teacher');
