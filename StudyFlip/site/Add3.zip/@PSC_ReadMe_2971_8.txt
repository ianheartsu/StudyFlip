Title: Add Records in Multiple Tabless
Description: About the code at first I dont know what is relational database is all about after some research in the Internet and study I come up with the code how to add records in multiple tables in MySQL and linked each one of them together to get a relevant information. I hope this code will help anyone interested not only in web programming but also in database design and development using PHP/MySQL.
 If you have some questions send me an email at jakerpomperada@yahoo.com. People here in the Philippines may contact me at my mobile number 09993969756.
Thank you very much.
Regards,
Mr. Jake Rodriguez Pomperada
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2971&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
