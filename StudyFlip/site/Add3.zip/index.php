<!-- Saving multiple records in four different tables in -->
<!-- PHP/MySQL Created By Mr. Jake Rodriguez Pomperada   -->
<!-- Date: November 8, 2011 Tuesday                      -->
<!-- Email Address: jakerpomperada@yahoo.com             -->
<!-- Mobile Number: 09993969756                          -->
<!-- Product of the Philippines                          -->




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Add Record in Multiple Tables</title>
<style type="text/css">
<!--
body {
	background-color: #0099FF;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style2 {color: #FFFFFF}
.style3 {
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style></head>

<body>
<p align="center" class="style3">ADDING OF RECORDS IN MULTIPLE TABLES</p>
<p align="center" class="style3">Created By: Mr. Jake R. Pomperada</p>
<p align="center" class="style3">Email Address: jakerpomperada@yahoo.com </p>

<form method="post" action="" name="form1" id="form1" >
<table width="533" border="0">
  <tr>
    <td width="64"><div align="justify" class="style2"><span class="style1">Name</span></div></td>
    <td width="459"><label>
      <input type="text" name="name" size=65 />
    </label></td>
  </tr>
  <tr>
    <td><div align="justify" class="style2"><span class="style1">Course</span></div></td>
    <td><input type="text" name="course" size=65 /></td>
  </tr>
  <tr>
    <td><div align="justify" class="style2"><span class="style1">School</span></div></td>
    <td><input type="text" name="school" size=65 /></td>
  </tr>
  <tr>
    <td><div align="justify" class="style2"><span class="style1">Address</span></div></td>
    <td><input type="text" name="address" size=65 /></td>
  </tr>
  <tr>
    <td><div align="justify" class="style2"><span class="style1">Work</span></div></td>
    <td><input type="text" name="work"  size=65/></td>
  </tr>
</table>
<br>
<input type="submit" name="save" value="Save Record">
<a href="join.php"> View Records </a>
</form>
</body>
</html>

<?php

error_reporting(0);

if($_POST['save'])
{
 $connection = mysql_connect ("localhost", "root","") 
   or die  (mysql_error());

 mysql_select_db ("class");
 
  $name=$_POST['name'];
  $course=$_POST['course'];
  $school=$_POST['school'];
  $address=$_POST['address'];
  $work=$_POST['work'];
 
 
 if (empty($name) || empty($course)  || 
     empty($school) || empty($address) ||
	 empty($work))
 {
  echo " <br>  <center> <h2> Textfield cannot be empty. </center> </h2>";
  exit();
    }
	else {
 // user table
  
  $query_1="INSERT INTO user (uid, name, course) VALUES (NULL, '$name', '$course')";
  mysql_query($query_1);
 
 // Get the previous ID of the first query statement 
 // in order to connect the 3 remaining queries in the 
 // 3 different tables
 
 $lastid=mysql_insert_id();

 // school table
 
 $query_2="INSERT INTO school (sid, sname) VALUES ($lastid, '$school')";
  mysql_query($query_2);
 
 // location table
 
 $query_3="INSERT INTO location (lid, address) VALUES ($lastid, '$address')";
  mysql_query($query_3);

// work table

 $query_4="INSERT INTO work (wid, work) VALUES ($lastid, '$work')";
  mysql_query($query_4);

  mysql_close($connection);
  
  echo "<br> <br>";
  echo " <h3>Record has been save in the database </h3>";
  }
}
?> 