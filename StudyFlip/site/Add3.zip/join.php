<?php
// Using of two table using inner join in MYSQL
// November 8, 2011 7:47 PM
// Created By: Jake R. Pomperada
// Email Address: jakerpomperada@yahoo.com
// Product of the Republic of the Philippines

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
$sql = 'SELECT user.name, user.course, school.sname,
        location.address,work.work
        FROM user,school,location,work
        WHERE user.uid = school.sid 
		AND user.uid = location.lid 
		AND user.uid = work.wid';
		
mysql_select_db('class');
$retval = mysql_query( $sql, $conn );
if(! $retval )
{
  die('Could not get data: ' . mysql_error());
}
echo "<h3><center> USING INNER JOIN IN PHP/MySQL </h3> </center>";


while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
{
    echo "Student Name : {$row['name']}	<br> ".
         "Course          : {$row['course']} <br> ".
         "School          : {$row['sname']} <br> ".
		 "Address         : {$row['address']} <br> ".
		 "Work            : {$row['work']} <br> ".
         "==================================<br>";
} 
echo "<b> Fetched data successfully\n </b>";
mysql_close($conn);
?>