-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 31, 2011 at 03:41 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblregistration`
--

CREATE TABLE IF NOT EXISTS `tblregistration` (
  `IDNO` int(11) NOT NULL AUTO_INCREMENT,
  `Name` tinytext,
  `Gender` tinytext,
  `Age` tinytext,
  `Course` tinytext,
  `Year_Level` tinytext,
  PRIMARY KEY (`IDNO`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tblregistration`
--

INSERT INTO `tblregistration` (`IDNO`, `Name`, `Gender`, `Age`, `Course`, `Year_Level`) VALUES
(5, 'Wayne Custer Alegata', 'Male', '33', 'BS Computer System', 'Fourth Year'),
(10, 'Jake Pomperada', 'Male', '33', 'Culinary Arts', 'Second Year'),
(11, 'Ma. Junallie Fuentebella', 'Female', '40', 'BS Chem Engineering', 'Fifth Year'),
(13, 'John Smith', 'Male', '45', 'BS Math', 'Third Year'),
(14, 'Ana Tan Chua', 'Female', '18', 'BS Accountancy', 'Fourth Year'),
(15, 'Manny Pacquiao', 'Male', '33', 'Army', 'Second Year'),
(16, 'Mamerto Logronio Jr.', 'Male', '33', 'BS ECE', 'Second Year'),
(17, 'Yao Ming', 'Male', '29', 'Agriculture', 'First Year');
