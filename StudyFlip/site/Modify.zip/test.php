<html>
<head>
<title>NCC College Student Information System </title>
<style type="text/css">
<!--
body {
	background-color: #99CC99;
}
.style3 {
	font-size: 18px;
	font-weight: bold;
	color: #FFFFFF;
	font-family: "Courier New", Courier, monospace;
}
.style4 {font-size: 24px; font-weight: bold; color: #CCFF33; }
.style5 {
	font-size: 16px;
	font-weight: bold;
	color: #000000;
	font-family: Arial, Helvetica, sans-serif;
}
.style6 {color: #003399}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<body>
<p align="center" class="style4 style6">NCC College Student Information System  </p>
<p align="center" class="style3">Created By Mr. Jake R. Pomperada, MAED-IT </p>
<p align="center" class="style5">Email Address: jakerpomperada@yahoo.com </p>
<form id="form1" name="form1" method="post" action="">
  <table width="459" border="1" align="center">
    <tr>
      <?php error_reporting(0); ?>
      <td width="126">ID No. </td>
      <td width="171"><label>
        <input name="tf_IDNO" type="text" id="tf_IDNO"  value="<?php 
 if($_POST["Search"]=="Search"){
mysql_connect("localhost","root","");
mysql_select_db("registration");
$qry = mysql_query("select * from tblregistration where IDNO ='". $_POST["tf_IDNO"]."'");
while($rs = mysql_fetch_array($qry)){
echo $rs["IDNO"];
}
}
 ?>"/>
      </label></td>
      <td width="140"><input name="Search" type="submit" id="Search" value="Search" /></td>
    </tr>
    <tr>
      <td>Name</td>
      <td colspan="2"><label>
        <input name="tf_Name" type="text" id="tf_Name" value="<?php 
if($_POST["Search"]=="Search"){
mysql_connect("localhost","root","");
mysql_select_db("registration");
$qry = mysql_query("select * from tblregistration where IDNO ='". $_POST["tf_IDNO"]."'");
while($rs = mysql_fetch_array($qry)){
echo $rs["Name"];
}
} ?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Gender</td>
      <td colspan="2"><input name="tf_Gender" type="text" id="tf_Gender" value="<?php 
if($_POST["Search"]=="Search"){
mysql_connect("localhost","root","");
mysql_select_db("registration");
$qry = mysql_query("select * from tblregistration where IDNO ='". $_POST["tf_IDNO"]."'");
while($rs = mysql_fetch_array($qry)){
echo $rs["Gender"];
}
} ?>"/>
          <label></label></td>
    </tr>
    <tr>
      <td>Age</td>
      <td colspan="2"><input name="tf_Age" type="text" id="tf_Age" value="<?php 
if($_POST["Search"]=="Search"){
mysql_connect("localhost","root","");
mysql_select_db("registration");
$qry = mysql_query("select * from tblregistration where IDNO ='". $_POST["tf_IDNO"]."'");
while($rs = mysql_fetch_array($qry)){
echo $rs["Age"];
}
} ?>"/></td>
    </tr>
    <tr>
      <td>Course</td>
      <td colspan="2"><input name="tf_Course" type="text" id="tf_Course" value="<?php 
if($_POST["Search"]=="Search"){
mysql_connect("localhost","root","");
mysql_select_db("registration");
$qry = mysql_query("select * from tblregistration where IDNO ='". $_POST["tf_IDNO"]."'");
while($rs = mysql_fetch_array($qry)){
echo $rs["Course"];
}
} ?>"/></td>
    </tr>
    <tr>
      <td>Year Level </td>
      <td colspan="2"><input name="tf_Year_Level" type="text" id="tf_Year_Level" value="<?php 
if($_POST["Search"]=="Search"){
mysql_connect("localhost","root","");
mysql_select_db("registration");
$qry = mysql_query("select * from tblregistration where IDNO ='". $_POST["tf_IDNO"]."'");
while($rs = mysql_fetch_array($qry)){
echo $rs["Year_Level"];
}
} ?>"/></td>
    </tr>
  </table>
  <td>
<br>
  </td>  

  <table width="200" border="1" align="center">
    <tr>
      <td><input name="Create" type="submit" id="Install" value="Create Database" /></td>
      <td><input name="Save" type="submit" id="Save" value="Save Record" /></td>
      <td><input name="Update" type="submit" id="Update" value="Update Record" /></td>
      <td><input name="Delete" type="submit" id="Delete" value="Delete Record" /></td>
    </tr>
  </table>
</form>
</body>
</html>

<?php
/*
code from 
http://j4guiang.blogspot.com
*/
mysql_connect("localhost","root","");
mysql_select_db("registration");

$idno = $_POST["tf_IDNO"];
$name = $_POST["tf_Name"];
$gender = $_POST["tf_Gender"];
$age = $_POST["tf_Age"];
$course = $_POST["tf_Course"];
$year_level = $_POST["tf_Year_Level"];

//Install Database Code
if($_POST["Create"]=="Create Database"){
mysql_query("create database registration") or die ("<center>creating database failed ".mysql_error())."</center>";
mysql_query("use registration") or die ("registration not exists".mysql_error());
mysql_query("create table tblregistration(IDNO int primary key auto_increment,Name text(30),Gender text(30),Age text(30),Course text(30),Year_Level text(30))") or die ("creating table failed ".mysql_error());
}

//Save button Code
if($_POST["Save"]=="Save Record"){
mysql_query("insert into tblregistration(Name,Gender,Age,Course,Year_Level)values('".$name."','".$gender."','".$age."','".$course."','".$year_level."')");
echo "<center>Save successful.</center>";
}

//Update button Code
if($_POST["Update"]=="Update Record"){
mysql_query("update tblregistration set Name ='".$name."',Gender ='".$gender."',Age='".$age."',Course='".$course."',Year_Level='".$year_level."' where IDNO ='".$idno."'");
echo "<center>update successful.</center>";
}

//Delete button Code
if($_POST["Delete"]=="Delete Record"){
mysql_query("delete from tblregistration where IDNO = '".$idno."'");
echo "<center>delete successful.</center>";
}

//Search for code button
if($_POST["Search"]=="Search"){
$str = $_POST['tf_IDNO'];
$length = strlen($str);
if($length == 0){
echo "<center>No input IDNO: <br> If you want to view all list of database just input any id and click search button</center>";
}else{
$qry = mysql_query("select * from tblregistration where IDNO ='".$idno."'");
$qry2 = mysql_query("select * from tblregistration");
$num_rows = mysql_num_rows($qry);
if($num_rows == 0){
echo "<center>No match IDNO for: ".$_POST['tf_IDNO']." <br><br> Available record are the following.<br><br></center>";
while($rs = mysql_fetch_array($qry2)){
echo"<center>";
echo "IDNO: ".$rs["IDNO"]." Name: ".$rs["Name"]." Gender: ".$rs["Gender"]." Age: ".$rs["Age"]." Course: ".$rs["Course"]." Year and Level: ".$rs["Year_Level"]."<br>";
}
}
while($rs = mysql_fetch_array($qry)){
echo"<center>";
echo "IDNO: ".$rs["IDNO"]." Name: ".$rs["Name"]." Gender: ".$rs["Gender"]." Age: ".$rs["Age"]." Course: ".$rs["Course"]." Year and Level: ".$rs["Year_Level"]."<br>";
}
}
}
?>