Title: NCC College Student Information System
Description: About this code a simple student information system that I wrote in PHP/MySQL: to demonstrate how to create database,table, add,edit,delete and search a particular record over the MySQL database good for beginners that are new in web database development.
If you have some question about my works please send me an email at jakerpomperada@yahoo.com. My mobile number here in the Philippines is 09993969756.
Thank you very much and Happy Programming.
Regards,
Mr. Jake Rodriguez Pomperada, MAED - IT

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2966&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
