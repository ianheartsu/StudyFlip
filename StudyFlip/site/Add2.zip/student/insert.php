<html>
<head>
<title>Record Confirmation</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#99FFFF">
<?php
$id = $_REQUEST['id'];
$first_name = strtoupper($_REQUEST['first_name']);
$last_name = strtoupper($_REQUEST['last_name']);

$connet=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("student") or die(mysql_error());

// Code for checking if the text field is empty using
// different conditions

$id_no = (empty($id));
$first_name2 = (empty($first_name)) ;
$last_name2 = (empty($last_name)); 

 if ($id_no == true  && $first_name2 == true 
     &&	$last_name2 == true) 
	 {
    echo "<h1> Please filled out the form correctly!</h1>";
	 }
else if ($first_name2 == true && $last_name2 == true)
   {
   echo "<h3> Both first name and  last name is not filled out correctly!</h1>";
 }
else if ($id_no == true && $first_name2 == true)
   {
   echo "<h3> Both ID No. and First Name is not filled out correctly!</h1>";
 }
else if ($id_no == true && $last_name2 == true)
   {
   echo "<h3> Both ID No. and Last Name is not filled out correctly!</h1>";
 }

else if ($id_no == true) 
   {
   echo "<h1> The student ID No. is not filled out correctly!</h1>";
 }
else if ($first_name2 == true)
   {
   echo "<h1> The student first name is not filled out correctly!</h1>";
 }
else if ($last_name2 == true)
   {
   echo "<h1> The student last name is not filled out correctly!</h1>";
 }
 
// Code for checking for duplicate record in the database
// for the first name and the last name of the student.

else if (mysql_num_rows(mysql_query("SELECT first_name,last_name
    FROM info WHERE first_name = '$first_name' AND
	last_name = '$last_name'"))) {
echo "<center> <br> <br> <h2> Sorry Duplicate Record for " 
      .$first_name. " " .$last_name. ". ";	   	
echo "<center> <h3> Please Try Again. "; 

}
else {	
$sql = "INSERT INTO info(id,first_name,last_name)
       VALUES ('$id','$first_name','$last_name')";
$query = mysql_query($sql) or die(mysql_error());
echo "<center> <br> <br> <h2> The record of "
     .$first_name. " " .$last_name.  
	 " has been saved in the database.";	   
}
?>
<br><br>
	<form method="post" action="">
<center>
<input type="submit" name="Submit2" value="Back To Main Menu"> 
</center>
</form>
<?php
  error_reporting(0);
  
 if ($_REQUEST['Submit2'])
 {
 header("location:main.php");
 }
?>
</body>
</html>
