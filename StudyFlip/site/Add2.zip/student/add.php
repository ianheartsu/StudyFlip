<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Add Student Record</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<form method="POST" action="insert.php">
<body bgcolor="#99FFFF">

<p align="center"><font size="5">Add Record</font></p>
<p align="left"> <strong>Student ID</strong> 
  <input type="text" name="id">
</p>
<p align="left"><strong>First Name</strong> 
  <input type="text" name="first_name">
</p>
<p align="left"><strong>Last Name </strong> 
  <input type="text" name="last_name">
</p>
<p align="left"> 
  <input type="submit" name="Submit" value="Add"> 
  <input type="reset">
</p>
</form>
<form method="post" action="">
  <div align="center">
    <input type="submit" name="Submit2" value="Back To Main Menu"> 
  </div>
</form>
<div align="center">
  <?php
error_reporting(0);
 if ($_REQUEST['Submit2'])
 {
 header("location:main.php");
 }
 ?>
</div>
</body>


</html>
