<html>
<head>
<title>Viewing of Student Records</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<title>List of Students</title>
<body bgcolor="#99FFFF">
<body>
<form method="post" action="">
  <input type="submit" name="Submit2" value="Back To Main Menu"> 
</form> 

<?php
  error_reporting(0);
  
 if ($_REQUEST['Submit2'])
 {
 header("location:main.php");
 }

?>

<table width="76%" border="1">
  <tr> 
 	<td><center><B>ID NO. </B></center></td>
    <td><center><B> FIRST NAME</B></center></td>
    <td><center><B> LAST NAME</B></center></td>
    <td><center><B> OPTIONS</B></center></td>
 </tr>


   
<?php
// Connect database.
error_reporting(0);
$host="localhost"; // Host name.
$db_user="root";
$db_password="";
$database="student"; // Database name.
mysql_connect($host,$db_user,$db_password) or die(mysql_error());
mysql_select_db($database) or die(mysql_error());

$start=$_GET['start']; // starting value of query


if(!isset($start)) $start = 0; //if $start is null then assign 0
$limit=10; // limits of records

$query="select * from info LIMIT $start,$limit";

$result=mysql_query($query) or die(mysql_error());

echo "<hr>";
echo "<h2><center> List of Students</h2>";
echo "<hr>";




while($myrows=mysql_fetch_array($result)){

$_html ="<tr> 
    <td>$myrows[id]</td>
    <td>$myrows[first_name]</td>
	<td>$myrows[last_name]</td>
    <td>
   <a href=\"edit.php?id=$myrows[id]&m=edit\">EDIT</a> | <a href=\"delete.php?id=$myrows[id]&m=del\">DELETE </a></td>
                                                    
    </tr> ";
 echo $_html;

}

/* Get total number of records */
$query = "SELECT count(*) as count FROM info";
$results = mysql_query($query);
$row = mysql_fetch_array($results);
$numrows = $row['count'];

$i=0; 
$number=1;

if($start > 0) {
echo "<a href=" . $_SERVER['PHP_SELF'] . "?start=" . ($start - $limit) .
">Previous</a>";
}

for($i=0;$i < $numrows;$i=$i+$limit){
if($number <> $i){
echo " <a href='".$_SERVER['PHP_SELF']."?start=$i'><font face='Arial' size='2'>$number</font></a>";
}
else { echo "<font face='Arial' size='2' color='red'>$number</font>";

} /// Current page is not displayed as link and given font color red
$number=$number+1;
}
if($numrows > ($start + $limit)){ 
 echo "&nbsp;&nbsp;<a href=\"" . $_SERVER['PHP_SELF'] . "?start=".($start + $limit).">Next</a>";
}
echo "<br> <br>";
?>
</body>

</html>
