-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 15, 2012 at 02:13 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student`
--
CREATE DATABASE student;
use student;
-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE IF NOT EXISTS `info` (
  `id` int(5) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `first_name`, `last_name`) VALUES
(10, 'WILSON', 'NG'),
(9, 'MICHAEL', 'CHUA'),
(8, 'FEMA', 'LAUREN'),
(7, 'MYRA', 'CASTILLO'),
(6, 'LINDA', 'LEE'),
(5, 'MIKE', 'JORDAN'),
(4, 'WAYNE', 'DELA CRUZ'),
(3, 'JOHN', 'SMITH'),
(2, 'MARIO ', 'CRUZ'),
(1, 'ALMA', 'MORENO'),
(11, 'SUNYA', 'CRUZ'),
(12, 'LEO', 'CORDOVA'),
(13, 'FERDINAND', 'MARCOS'),
(14, 'MARY', 'ZAMORA'),
(15, 'SCOTTIE', 'PIPPEN'),
(16, 'DENNIS', 'RODMAN'),
(17, 'JOEY', 'DE LEON'),
(18, 'VIC', 'SOTTO'),
(19, 'ARNEL', 'MAGHINAY'),
(20, 'MAMERTO', 'LOGRONIO');
