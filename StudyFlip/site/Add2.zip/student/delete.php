<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<?php 

	$connet=mysql_connect("localhost","root","")
	 or die(mysql_error());
    $db=mysql_select_db("student") or die(mysql_error());
	$sid=$_GET['id'];
   	$sql = "SELECT * FROM info WHERE id= '$sid' ";
	$result = mysql_query($sql); 
	$r=mysql_fetch_object($result); 
?>

<html>
<head>
	<title> Delete Record Module </title>
</head>
<body bgcolor="#99FFFF" text="#000000">
<h1 align="center"><font face="Times New Roman, Times, serif"><b>Delete Page</b></font></h1>
	<?php 
    error_reporting(0);
	$sid=$_GET['id'];
	$fname=$_GET['first_name'];

	 // Code to delete the record in the database
	 $action	= $_GET['m'];
     
		if ($action=="del") {
	       $sql3="Delete FROM info where id ='$sid' ";
						
			if(!$q=mysql_query($sql3) ) {
				echo mysql_error();
			}
	
		else if($q=mysql_query($sql3) ) {
			echo '<br/><h3 align="center"> Student Record successfully deleted.</h3>';	
			}
		} 
		else {
			echo '<br/><h3 align="center"> Student Record did not deleted.</h3>';
		}	
	
	?>	
	<p align="center">
		
	</p>
	<form method="post" action="">
<center>
<input type="submit" name="Submit2" value="Back To Main Menu"> 
</center>
</form>
<?php
  error_reporting(0);
  
 if ($_REQUEST['Submit2'])
 {
 header("location:main.php");
 }
?>
</body>

</html>

