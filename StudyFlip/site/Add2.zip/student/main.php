<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
body {
	background-color: #99FFFF;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 24px;
	font-weight: bold;
}
-->
</style></head>

<body>
<form method="post" action="">
<p>&nbsp;</p>
<p align="center" class="style1">Student Record Information System</p>
<p align="center" class="style1">Main Menu</p>
<p align="center" class="style1">&nbsp;</p>

<table width="542" border="0">
  <tr>
    <td width="103">&nbsp;</td>
    <td width="12">&nbsp;</td>
    <td width="109"><input type="submit" name="submit1" value="ADD RECORD" /></td>
    <td width="84">&nbsp;</td>
    <td width="212"><input type="submit" name="submit2" value="VIEW RECORD" /></td>
  </tr>
</table>
</form>
<?php
error_reporting(0);
if ($_REQUEST['submit1']){
header("location:add.php");
}

if ($_REQUEST['submit2']){
header("location:paging.php");
}
?>


</body>
</html>
