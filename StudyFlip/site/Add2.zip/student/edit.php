<?php
	error_reporting(0);
	$connet=mysql_connect("localhost","root","") or die(mysql_error());
	$db=mysql_select_db("student") or die(mysql_error());

	$sid = $_GET['id'];

	$sql = "SELECT * FROM info where id = '$sid' ";
	$result = mysql_query($sql); 
	$rs=mysql_fetch_object($result); 
 
?>

		

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Modify Student Record</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<form method ="POST" name = "p" action=" ">
<body bgcolor="#99FFFF">
<h1 align="center"><font size="5" face="Times New Roman, Times, serif">Edit Record</font></h1>
<p align="left"> <strong>Student ID</strong> 
   <?php echo "<b>".$rs->id;?> 

</p>
<p align="left"><strong>First Name</strong> 
  <input type="text" name="first_name" value="<?php echo $rs-> first_name ?>">

</p>
<p align="left"><strong>Last Name </strong> 
  <input type="text" name="last_name" value="<?php  echo $rs-> last_name ?>">
</p>
<p align="left"> 
  <input type="Submit" name="p" value="Submit">
</p>
<p align="left">
  <input type="submit" name="Submit2" value="Back To Main Menu"> 
</p>
<?php
  error_reporting(0);
  
 if ($_REQUEST['Submit2'])
 {
 header("location:main.php");
 }
?>
</body>
</html>

<?php
       error_reporting(0);
		$x = $_POST["p"];
		if ($x=="Submit") {
		$fname = strtoupper($_POST['first_name']);
		$lname= strtoupper($_POST['last_name']);
				
		$sql2= "UPDATE info SET first_name = '$fname',last_name = '$lname' 
		        WHERE id ='$sid'";
	    mysql_query($sql2)or die(mysql_error());  
				

		echo "<br><br><h3><center>Record Successfully Updated</h3></center>";
       } 
   ?>