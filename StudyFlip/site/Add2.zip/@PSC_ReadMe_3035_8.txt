Title: Simple Student Information System
Description: A simple student information system that I wrote in PHP/MySQL it contains code for error detection of entries and checking for duplicate records. I also include the SQL dump file for the database and tables creation. If you find my work useful please send me an email at jakerpomperada@yahoo.com. Be one of my friends in Facebook my address is jakerpomperada@yahoo.com.
People here in the Philippines who wish to contact me can reach me in my mobile phone number 09993969756 and 09154628025.
Thank you very much.
Regards,
Mr. Jake Rodriguez Pomperada, MAED - Instructional Technology
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3035&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
