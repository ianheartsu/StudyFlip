<?
	include "header.php";
?>
<HTML>
	<HEAD>
		<TITLE>Phonebook - Register</TITLE>
	</HEAD>
	<BODY>
		<p>
			<?
				if($_SESSION['loggedin']=='0')
				{
			?>
				<FORM action="doregister.php" method="post">
					<CENTER>
						<BR>
						<TABLE border='1' cellspacing='0' cellpadding='5'>
							<TR>
								<TD colspan=2>
									<CENTER><big><B>Register</B></big></CENTER>
								</TD>
							</TR>
							<TR>
								<TD>Username : </TD>
								<TD><INPUT Type="text" name="txtUser" /></TD>
							</TR>
								<TD>Password : </TD>
								<TD><INPUT Type="password" name="txtPass" /></TD>
							<TR>
								<TD>Name : </TD>
								<TD><INPUT Type="text" name="txtName" /></TD>
							</TR>
							<TR>
								<TD>Email ID : </TD>
								<TD><INPUT Type="text" name="txtEmail" /></TD>
							</TR>
							<TR>
								<TD colspan=2>
									<CENTER><INPUT Type="submit" value="Register" /></CENTER>
								</TD>
							</TR>
						</TABLE>
					</CENTER>
				</FORM>
			<?
				}
				else
				{
					header("Location:default.php");
				}
			?>
		</p>
	</BODY>
<HTML>
<?
	include "footer.php";
?>