<?
	include "header.php";

	//users - ID, username, password, name, emailid
	if(!empty($_SESSION['loggedin']) && $_SESSION['loggedin']=='1')
	{
	?>
		<CENTER>
		<BR>
			<TABLE border='0' cellspacing='0' cellpadding='5'>
				<TR><TD colspan=2><CENTER><U><B>Profile</B></U><CENTER></TD></TR>
				<TR><TD>Username</TD><TD> : <?=$_SESSION['username']?></TD></TR>
				<TR><TD>Name</TD><TD> : <?=$_SESSION['name']?></TD></TR>
				<TR><TD>Email ID</TD><TD> : <?=$_SESSION['emailid']?></TD></TR>
			</TABLE>
		</CENTER>
	<?
	}
	else
	{
		header("Location:default.php");
	}
	include "footer.php";
?>