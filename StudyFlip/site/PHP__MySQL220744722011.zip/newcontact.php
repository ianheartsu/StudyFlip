<?
	include "header.php";
?>
<HTML>
	<HEAD>
		<TITLE>Phonebook - Add Contact</TITLE>
	</HEAD>
	<BODY>
		<p>
			<?
				if($_SESSION['loggedin']=='1')
				{
			?>
				<FORM action="savecontact.php" method="post">
					<CENTER>
						<TABLE border='0' cellspacing='0' cellpadding='5'>
							<TR>
								<TD colspan=2>
									<CENTER><B><U>New Contact</U></B></CENTER>
								</TD>
							</TR>
							<TR>
								<TD>Name</TD>
								<TD> : <INPUT Type="text" name="txtName" /></TD>
							</TR>
								<TD>Number</TD>
								<TD> : <INPUT Type="text" name="txtNumber" /></TD>
							<TR>
								<TD colspan=2>
									<CENTER><INPUT Type="submit" value="Save" /></CENTER>
								</TD>
							</TR>
						</TABLE>
					</CENTER>
				</FORM>
			<?
				}
				else
				{
					header("Location:default.php");
				}
			?>
		</p>
	</BODY>
<HTML>
<?
	include "footer.php";
?>