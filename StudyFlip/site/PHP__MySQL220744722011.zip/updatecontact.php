<?
	include "header.php";
	
	//contacts - ID, cname, cnumber, userid
	$oname  = mysql_real_escape_string($_POST["oname"]);
	$name   = mysql_real_escape_string($_POST["txtName"]);
	$number = mysql_real_escape_string($_POST["txtNumber"]);
	$userid = mysql_real_escape_string($_SESSION['username']);
	
	if(!empty($_POST['txtName']) && !empty($_POST['txtNumber']))
	{
		$rs = mysql_query("UPDATE contacts set cname='$name', cnumber='$number' WHERE cname='$oname' AND userid='$userid';",$conn);
		if($rs>0)
		{
			echo "<CENTER><br>The contact updated successfully!</CENTER>";
		}
		else
		{
			echo "<CENTER><br>Updating contact failed!</CENTER>";
		}
	}
	else
	{
			echo "<CENTER><br>Please enter name and number correctly.</CENTER>";
	}
	mysql_close();
	include "footer.php";
?>