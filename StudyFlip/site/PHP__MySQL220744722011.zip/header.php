<?php session_start();
	$dbhost = "localhost";
	$dbname = "phonebook";
	$dbuser = "root";
	$dbpass = "mysql";

	$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die("MySQL Error: " . mysql_error());
	mysql_select_db($dbname) or die("MySQL Error: " . mysql_error());

	echo "<CENTER><HR><HR><H1>-Phonebook-</H1><HR></CENTER>";
		
	if (empty($_SESSION['loggedin']))
	{
		$_SESSION['loggedin']='0';
		$title = '';
	}
	elseif (!empty($_SESSION['loggedin']) && $_SESSION['loggedin']=='0')
	{
		$title = '';
	}
	elseif (!empty($_SESSION['loggedin']) && $_SESSION['loggedin']=='1')
	{
		$_SESSION['loggedin']='1';
		$title=' - '.$_SESSION['name'];
	}
?>

<CENTER>
		<? 
		if($_SESSION['loggedin']=='1')
		{
		?>
			<FIELDSET> <!-- id='menu' height='50' border='1' color='black'>-->
				<BIG><BIG><B>
				<A href='default.php'>Home</A> |
				<A href='viewpb.php'>View Phonebook</A> |
				<A href='newcontact.php'>New Contact</A> |
				<A href='profile.php'>Profile</A> |
				<A href='logout.php'>Logout</A>
				</B></BIG></BIG>
			</FIELDSET>
		<?
		}
		else
		{
		?>
			<FIELDSET> <!-- id='menu' height='50' border='1' color='black'>-->
				<BIG><BIG><B>
				<A href='default.php'>Home</A> |
				<A href='register.php'>Register</A> |
				<A href='login.php'>Login</A>
				</B></BIG></BIG>
			</FIELDSET>		
		<?
		}
		?>
</CENTER>