<?
	include "header.php";
?>
<HTML>
	<HEAD>
		<TITLE>Phonebook<? echo "$title"; ?></TITLE>
	</HEAD>
	<BODY>
		<CENTER>
		<br>
		<p>
			Welcome to your online Phonebook.<BR>
			Here you can create your own phonebook.<BR>
			Now you can access your contacts from<BR>
			anywhere on the internet.<BR><BR>
		</p>
		</CENTER>
	</BODY>
<HTML>
<?
	include "footer.php";
?>