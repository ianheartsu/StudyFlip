<?
	echo "<BR><BR><CENTER><HR><HR><H4>Your easy to use web based Phonebook</H4><HR></CENTER>"
?>