<?
	include "header.php";
?>
<HTML>
	<HEAD>
		<TITLE>Phonebook<? echo "$title"; ?></TITLE>
	</HEAD>
	<BODY>
		<CENTER>
			<?
			//contacts - ID, cname, cnumber, userid
			$rs=mysql_query("SELECT * FROM contacts WHERE userid='".$_SESSION['username']."';",$conn) or die("Couldn't fetch records from stud");
			$count=mysql_num_rows($rs);
			if ($count>0)
			{
				echo "<CENTER>";
				echo "<BR><B><U>Contacts</U></B><BR>";
				echo "<TABLE align='center' border='1' cellspacing='0' cellpadding='5' color='black'>";
				echo "<TR><TH>Name</TH><TH>Number</TH><TH>&nbsp;</TH><TH>&nbsp;</TH></TR>";
				$i=0;
				while($i<$count)
				{
					$cname=mysql_result($rs, $i, "cname");
					$cnum=mysql_result($rs, $i, "cnumber");
					echo "<TR><TD>$cname</TD><TD>$cnum</TD><TD><A href='editcontact.php?n=$cname&p=$cnum'>Edit</A></TD><TD><A href='delcontact.php?n=$cname&p=$cnum'>Delete</A></TD></TR>";
					$i++;
				}
				echo "</TABLE></CENTER>";
			}
			else
			{
				echo "<CENTER><br>No contacts saved.</CENTER>";
			}
			mysql_close();

			?>
		</CENTER>
	</BODY>
<HTML>
<?
	include "footer.php";
?>