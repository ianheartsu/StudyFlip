<?
	include "header.php";
	$name=$_GET["n"];
	$phone=$_GET["p"];
	$userid=$_SESSION["username"];
	if($_SESSION['loggedin']=='1')
	{
		$rs = mysql_query("DELETE FROM contacts WHERE cname='$name' AND cnumber='$phone' AND userid='$userid';",$conn);
		echo "<CENTER>";
		echo "<br>Deleted contact details...<BR>";
		echo "Name:.$name<BR>";
		echo "Number:.$phone";
		echo "</CENTER>";
		mysql_close();
	}
	else
	{
		header("Location:default.php");
	}
	include "footer.php";
?>