<?
	include "header.php";
	//users - ID, username, password, name, emailid
	$user=mysql_real_escape_string($_POST["txtUser"]);
	$pass=md5(mysql_real_escape_string($_POST["txtPass"]));
	$name=mysql_real_escape_string($_POST["txtName"]);
	$email=mysql_real_escape_string($_POST["txtEmail"]);
	if(!empty($_POST['txtUser']) && !empty($_POST['txtPass']) && !empty($_POST['txtName']) && !empty($_POST['txtEmail']))
	{
		$rs = mysql_query("SELECT * FROM users WHERE username='$user';",$conn);
		if(mysql_num_rows($rs)>0)
		{
			echo "<CENTER><BR>Sorry that username is already taken. Please try with different username.</CENTER>";
			//header("Location:default.php");
		}
		else
		{
			mysql_query("INSERT INTO users(username, password, name, emailid) VALUES('$user','$pass','$name','$email');",$conn);
			echo "<CENTER><BR>Congratulations ".$_POST['txtName']."! Your registration is successful.</CENTER>";
		}
	else
	{
		echo "<CENTER><br>Please enter all details correctly.</CENTER>";
	}
	mysql_close();
	include "footer.php";
?>