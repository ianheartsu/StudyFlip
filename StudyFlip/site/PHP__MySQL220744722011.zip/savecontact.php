<?
	include "header.php";
	
	//contacts - ID, cname, cnumber, userid
	$name   = mysql_real_escape_string($_POST["txtName"]);
	$number = mysql_real_escape_string($_POST["txtNumber"]);
	$userid = mysql_real_escape_string($_SESSION['username']);
	
	if(!empty($_POST['txtName']) && !empty($_POST['txtNumber']))
	{
		$rs = mysql_query("SELECT * FROM contacts WHERE cname='$name' AND cnumber='$number' AND userid='$userid';",$conn);
		if(mysql_num_rows($rs)>0)
		{
			echo "<CENTER><br>The contact with this name already exists!</CENTER>";
		}
		else
		{
			mysql_query("INSERT INTO contacts(cname, cnumber, userid) VALUES('$name','$number','$userid');",$conn);
			echo "<CENTER><br>Contact saved successfully.</CENTER>";
		}
	}
	else
	{
		echo "<CENTER><br>Please enter name and number correctly.</CENTER>";	
	}
	mysql_close();
	include "footer.php";
?>