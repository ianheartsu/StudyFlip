<?
	include "header.php";
	
	//users - ID, username, password, name, emailid
	$user=mysql_real_escape_string($_POST["txtUser"]);
	$pass=md5(mysql_real_escape_string($_POST["txtPass"]));
	$rs = mysql_query("SELECT * FROM users WHERE username='$user' AND password='$pass';",$conn);
	if(mysql_num_rows($rs)==1)
	{
		$_SESSION['loggedin']='1';
		$_SESSION['username']=mysql_result($rs,0,'username');
		$_SESSION['name']=mysql_result($rs,0,'name');
		$_SESSION['emailid']=mysql_result($rs,0,'emailid');
		header("Location:default.php");		
	}
	else
	{
		$_SESSION['loggedin']='0';
		$_SESSION['username']='';
		$_SESSION['name']='';
		$_SESSION['emailid']='';
		echo "<CENTER>Invalid username and/or password. Please try again.</CENTER>";
	}
	mysql_close();
	include "footer.php";
?>