<?
	include "header.php";
?>
<HTML>
	<HEAD>
		<TITLE>Phonebook - Login</TITLE>
	</HEAD>
	<BODY>
		<p>
			<?
				if($_SESSION['loggedin']=='0')
				{
			?>
				<FORM action="dologin.php" method="post">
					<BR>
					<CENTER>
						<TABLE border='1' cellspacing='0' cellpadding='5'>
							<TR>
								<TD colspan=2>
									<CENTER><big><B>Login</B></big></CENTER>
								</TD>
							</TR>						
							<TR>
								<TD>Username : </TD>
								<TD><INPUT Type="text" name="txtUser" /></TD>
							</TR>
								<TD>Password : </TD>
								<TD><INPUT Type="password" name="txtPass" /></TD>
							<TR>
								<TD colspan=2>
									<CENTER><INPUT Type="submit" value="Login" /></CENTER>
								</TD>
							</TR>
						</TABLE>
					</CENTER>
				</FORM>
			<?
				}
				else
				{
					header("Location:default.php");
				}
			?>
		</p>
	</BODY>
<HTML>
<?
	include "footer.php";
?>