<?
	include "header.php";
?>
<HTML>
	<HEAD>
		<TITLE>Phonebook - Edit Contact</TITLE>
	</HEAD>
	<BODY>
		<p>
			<?
				if($_SESSION['loggedin']=='1')
				{
			?>
				<FORM action="updatecontact.php" method="post">
					<INPUT Type="hidden" name="oname" value="<?=$_GET['n']?>">
					<CENTER>
						<TABLE border='0' cellspacing='0' cellpadding='5'>
							<TR>
								<TD colspan=2>
									<CENTER><B><U>Edit Contact</U></B></CENTER>
								</TD>
							</TR>						
							<TR>
								<TD>Name : </TD>
								<TD><INPUT Type="text" name="txtName" value="<?=$_GET['n']?>" /></TD>
							</TR>
								<TD>Number : </TD>
								<TD><INPUT Type="text" name="txtNumber" value="<?=$_GET['p']?>" /></TD>
							<TR>
								<TD colspan=2>
									<CENTER><INPUT Type="submit" value="Update" /></CENTER>
								</TD>
							</TR>
						</TABLE>
					</CENTER>
				</FORM>
			<?
				}
				else
				{
					header("Location:default.php");
				}
			?>
		</p>
	</BODY>
<HTML>
<?
	include "footer.php";
?>