<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// translated by Zmicer Harachka [http://www.zmicer.com]
// UTF-8 Belarussian Language Settings


define('DDFM_SUBMITBUTTON', 'Даслаць паведамленне');

define('DDFM_CREDITS', 'Аўтар');

define('DDFM_CONFIRMPASS', 'Падцвержанне');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Памылкі!');

define('DDFM_MAXCHARLIMIT', 'ліміт сымбалаў для');

define('DDFM_MISSINGFIELD', 'Адсутнічае абавязковае поле ');

define('DDFM_INVALIDINPUT', 'Няслышны ўвод для');

define('DDFM_INVALIDEMAIL', 'Няслушны адрас электроннай скрынкі');

define('DDFM_INVALIDURL', 'Няслышны URL старонкі');

define('DDFM_NOMATCH', 'Палі не супадаюць з');

define('DDFM_MISSINGVER', 'Увядзіце праверачны код');

define('DDFM_NOVERGEN', 'Праверачны код не створаны');

define('DDFM_INVALIDVER', 'Няслушны праверачны код');

define('DDFM_MISSINGFILE', 'Адсутнічае абавязковы файл');

define('DDFM_FILETOOBIG', 'Файл празмерна вялікі:');

define('DDFM_ATTACHED', 'Файл прыкрэплены');

define('DDFM_INVALIDEXT', 'Няслышны тып файла:');

define('DDFM_UPLOADERR', 'Памылка загрузкі:');

define('DDFM_SERVERERR', '<p>Памылка дасылкі паведамлення!</p>');

define('DDFM_GDERROR', '<p>Модуль GD не знойдзены, ён неабходны для генерацыі кадоў верыфікацыі!</p>');

?>