<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Slovak Language Settings


define('DDFM_SUBMITBUTTON', 'Po�li e-mail');

define('DDFM_CREDITS', 'Script by');

define('DDFM_CONFIRMPASS', 'Odosla�');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Chyba!');

define('DDFM_MAXCHARLIMIT', 'limit pre po�et znakov');

define('DDFM_MISSINGFIELD', 'Vypl�te povinn� polia ');

define('DDFM_INVALIDINPUT', 'Nespr�vne vyplnen� pole');

define('DDFM_INVALIDEMAIL', 'Nespr�vne vyplnen� e-mailov� adresa');

define('DDFM_INVALIDURL', 'Nespr�vne vyplnen� URL');

define('DDFM_NOMATCH', 'Polia nes�hlasia');

define('DDFM_MISSINGVER', 'Zadajte k�d');

define('DDFM_NOVERGEN', 'Verifika�n� k�d nebol vygenerovan�');

define('DDFM_INVALIDVER', 'Zle zadan� k�d');

define('DDFM_MISSINGFILE', 'Ch�ba povinn� pole');

define('DDFM_FILETOOBIG', 'S�bor je pr�li� ve�k�:');

define('DDFM_ATTACHED', 'S�bor pripojen�');

define('DDFM_INVALIDEXT', 'Chybn� typ s�boru:');

define('DDFM_UPLOADERR', 'Chyba uploadu:');

define('DDFM_SERVERERR', '<p>Chyba pri odosielan�!</p>');

define('DDFM_GDERROR', '<p>GD nebolo detekovan�! GD je po�adovan� na vytvorenie verifika�n�ho k�du.</p>');


?>