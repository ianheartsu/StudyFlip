<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Italian Language Settings


define('DDFM_SUBMITBUTTON', 'Invia messaggio');

define('DDFM_CREDITS', 'Script a cura di');

define('DDFM_CONFIRMPASS', 'Conferma');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Errori!');

define('DDFM_MAXCHARLIMIT', 'limite di caratteri');

define('DDFM_MISSINGFIELD', 'Campo richiesto mancante ');

define('DDFM_INVALIDINPUT', 'Dato inserito non valido per');

define('DDFM_INVALIDEMAIL', 'Indirizzo email non valido per');

define('DDFM_INVALIDURL', 'URL non valido per');

define('DDFM_NOMATCH', 'I campi non corrispondono per');

define('DDFM_MISSINGVER', 'Inserire il codice di verifica');

define('DDFM_NOVERGEN', 'Nessun codice di verifica generato');

define('DDFM_INVALIDVER', 'Codice di verifica non valido');

define('DDFM_MISSINGFILE', 'Manca file richiesto');

define('DDFM_FILETOOBIG', 'Il file &egrave; troppo pesante:');

define('DDFM_ATTACHED', 'File allegato');

define('DDFM_INVALIDEXT', 'Tipo di file non valido:');

define('DDFM_UPLOADERR', 'Errore in caricamento:');

define('DDFM_SERVERERR', '<p>Errore inviando il messaggio!</p>');

define('DDFM_GDERROR', '<p>Librerie GD non trovate! Le librerie GD sono necessarie per creare il codice di verifica.</p>');


?>