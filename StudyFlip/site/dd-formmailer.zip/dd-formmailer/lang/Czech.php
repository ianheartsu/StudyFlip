<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Czech Language Settings


define('DDFM_SUBMITBUTTON', 'Po&#353;li Email');

define('DDFM_CREDITS', 'Script by');

define('DDFM_CONFIRMPASS', 'Potvrdit');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Chyba!');

define('DDFM_MAXCHARLIMIT', 'omezen&yacute; po&#269;et znak&#367; pro');

define('DDFM_MISSINGFIELD', 'Chyb&iacute; po&#382;adovan&eacute; &uacute;daje ');

define('DDFM_INVALIDINPUT', 'Nespr&aacute;vn&#283; vypln&#283;n&eacute; pole');

define('DDFM_INVALIDEMAIL', 'Neplatn&yacute; email pro ');

define('DDFM_INVALIDURL', 'Nespr&aacute;vn&#283; vypln&#283;n&yacute; URL');

define('DDFM_NOMATCH', '&Uacute;daje nesouhlas&iacute; ');

define('DDFM_MISSINGVER', 'Vypl&#328;t&#283; ov&#283;&#345;ovac&iacute; k&oacute;d');

define('DDFM_NOVERGEN', 'Ov&#283;&#345;ovac&iacute; k&oacute;d nevygenerov&aacute;n');

define('DDFM_INVALIDVER', 'Neplatn&yacute; ov&#283;&#345;ovac&iacute; k&oacute;d');

define('DDFM_MISSINGFILE', 'Chyb&iacute; &uacute;daje v povinn&eacute;m poli');

define('DDFM_FILETOOBIG', 'Subor je p&#345;&iacute;li&#353; velk&yacute;:');

define('DDFM_ATTACHED', 'Soubor p&#345;ipojen');

define('DDFM_INVALIDEXT', 'Neplatn&yacute; typ souboru:');

define('DDFM_UPLOADERR', 'Chyba p&#345;i uploadu:');

define('DDFM_SERVERERR', '<p>Chyba p&#345;i odesl&aacute;n&iacute;!</p>');

define('DDFM_GDERROR', '<p>GD nenalezen! GD po&#382;adov&aacute;n na vytvo&#345;en&iacute; ov&#283;&#345;ovac&iacute;ho k&oacute;du..</p>');

?>