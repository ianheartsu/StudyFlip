<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Finnish Language Settings


define('DDFM_SUBMITBUTTON', 'L&auml;het&auml;');

define('DDFM_CREDITS', 'Laatinut');

define('DDFM_CONFIRMPASS', 'Varmista');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Virhe on tapahtunut');

define('DDFM_MAXCHARLIMIT', 'Merkkej&auml; enint&auml;&auml;n');

define('DDFM_MISSINGFIELD', 'Pakollinen tieto puuttuu');

define('DDFM_INVALIDINPUT', 'Virhe lomakkeessa');

define('DDFM_INVALIDEMAIL', 'S&auml;hk&ouml;postiosoite ei kelpaa');

define('DDFM_INVALIDURL', 'URL ei kelpaa');

define('DDFM_NOMATCH', 'Seuraavat kent&auml;t eiv&auml;t kelpaa');

define('DDFM_MISSINGVER', 'Sy&ouml;t&auml; varmistuskoodi');

define('DDFM_NOVERGEN', 'Varmistuskoodia ei ole luotu');

define('DDFM_INVALIDVER', 'Virheellinen varmistuskoodi');

define('DDFM_MISSINGFILE', 'Vaadittu tiedosto puuttuu');

define('DDFM_FILETOOBIG', 'Tiedostokoko on liian suuri:');

define('DDFM_ATTACHED', 'Tiedosto liitetty');

define('DDFM_INVALIDEXT', 'Virheellinen tiedostomuoto:');

define('DDFM_UPLOADERR', 'Tiedoston siirtovirhe:');

define('DDFM_SERVERERR', '<p>Virhe viesti&auml; l&auml;hetett&auml;ess&auml;!</p>');

define('DDFM_GDERROR', '<p>GD:t&auml; ei l&ouml;ytynyt! GD on pakollinen kuvavarmmistustoiminnossa.</p>');


?>