<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Slovene Language Settings by http://kosir.info


define('DDFM_SUBMITBUTTON', 'Po&scaron;lji');

define('DDFM_CREDITS', 'Script by');

define('DDFM_CONFIRMPASS', 'Ponovite');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Napake!');

define('DDFM_MAXCHARLIMIT', 'character limit for');

define('DDFM_MISSINGFIELD', 'Polja ozna&#269;ena z * so obvezna! ');

define('DDFM_INVALIDINPUT', 'Napaka pri');

define('DDFM_INVALIDEMAIL', 'Nepravilen elektronski naslov za');

define('DDFM_INVALIDURL', 'Nepravilen URL naslov za');

define('DDFM_NOMATCH', 'Geslo se ne ujema. Napaka pri');

define('DDFM_MISSINGVER', 'Vpi&scaron;ite verifikacijsko kodo');

define('DDFM_NOVERGEN', 'Verifikacijska koda ni bila zgenerirana');

define('DDFM_INVALIDVER', 'Nepravilna verifikacijska koda');

define('DDFM_MISSINGFILE', 'Manjka datoteka');

define('DDFM_FILETOOBIG', 'Datoteka je prevelika:');

define('DDFM_ATTACHED', 'Priponka');

define('DDFM_INVALIDEXT', 'Neveljavna datoteka:');

define('DDFM_UPLOADERR', 'Napaka pri prenosu:');

define('DDFM_SERVERERR', '<p>Napaka pri po&scaron;iljanju sporo&#269;ila!</p>');

define('DDFM_GDERROR', '<p>GD not detected! GD is required for the image verification feature.</p>');


?>