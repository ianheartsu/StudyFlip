<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Portuguese Language Settings
// Portuguese translation by Ze Nuno  jnp@art.com.pt	2007/04/19


define('DDFM_SUBMITBUTTON', 'Envie E-mail');

define('DDFM_CREDITS', 'Script por');

define('DDFM_CONFIRMPASS', 'Confirme');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Erros!');

define('DDFM_MAXCHARLIMIT', 'limite no num. de caracteres para');

define('DDFM_MISSINGFIELD', 'Campo necessário não encontrado ');

define('DDFM_INVALIDINPUT', 'Input inválido para');

define('DDFM_INVALIDEMAIL', 'Endereço e-mail inválido para');

define('DDFM_INVALIDURL', 'URL inválido URL para');

define('DDFM_NOMATCH', 'Os campos não conferem para');

define('DDFM_MISSINGVER', 'Introduza o código de verificação');

define('DDFM_NOVERGEN', 'O código de verificação não foi gerado');

define('DDFM_INVALIDVER', 'Código de verificação inválido');

define('DDFM_MISSINGFILE', 'Ficheiro necessário não encontrado');

define('DDFM_FILETOOBIG', 'Ficheiro demasiado grande:');

define('DDFM_ATTACHED', 'Ficheiro anexo');

define('DDFM_INVALIDEXT', 'Tipo de ficheiro inválido:');

define('DDFM_UPLOADERR', 'Erro no Upload:');

define('DDFM_SERVERERR', '<p>Erro no envio de mensagem!</p>');

define('DDFM_GDERROR', '<p>GD não detectado! GD é requerido para a imagem de verificação.</p>');


?>