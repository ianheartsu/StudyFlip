<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// translated by http://lexa.tenet.ua/blog/
// UTF-8 Russian Language Settings


define('DDFM_SUBMITBUTTON', 'Отправить сообщение');

define('DDFM_CREDITS', 'Автор');

define('DDFM_CONFIRMPASS', 'Подтверждение');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Ошибки!');

define('DDFM_MAXCHARLIMIT', 'лимит символов для');

define('DDFM_MISSINGFIELD', 'Отсутствует обязательное поле ');

define('DDFM_INVALIDINPUT', 'Неверный ввод для');

define('DDFM_INVALIDEMAIL', 'Неправильный адрес email');

define('DDFM_INVALIDURL', 'Неверный URL');

define('DDFM_NOMATCH', 'Поля не совпадают с');

define('DDFM_MISSINGVER', 'Введите проверочный код');

define('DDFM_NOVERGEN', 'Проверочный код не создан');

define('DDFM_INVALIDVER', 'Неверный проверочный код');

define('DDFM_MISSINGFILE', 'Отсутствует обязательный файл');

define('DDFM_FILETOOBIG', 'Файл слишком большой:');

define('DDFM_ATTACHED', 'Файл прикреплён');

define('DDFM_INVALIDEXT', 'Неверный тип файла:');

define('DDFM_UPLOADERR', 'Ошибка загрузки:');

define('DDFM_SERVERERR', '<p>Ошибка отправки сообщения!</p>');

define('DDFM_GDERROR', '<p>Модуль GD не найден, он необходим для генерации кодов верификации!</p>');

?>