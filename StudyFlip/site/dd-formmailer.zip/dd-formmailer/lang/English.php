<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// English Language Settings


define('DDFM_SUBMITBUTTON', 'Send Email');

define('DDFM_CREDITS', 'Script by');

define('DDFM_CONFIRMPASS', 'Confirm');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Errors!');

define('DDFM_MAXCHARLIMIT', 'character limit for');

define('DDFM_MISSINGFIELD', 'Missing required field ');

define('DDFM_INVALIDINPUT', 'Invalid input for');

define('DDFM_INVALIDEMAIL', 'Invalid email address for');

define('DDFM_INVALIDURL', 'Invalid URL for');

define('DDFM_NOMATCH', 'Fields do not match for');

define('DDFM_MISSINGVER', 'Enter the verification code');

define('DDFM_NOVERGEN', 'No verification code generated');

define('DDFM_INVALIDVER', 'Invalid verification code');

define('DDFM_MISSINGFILE', 'Missing required file');

define('DDFM_FILETOOBIG', 'File is too large:');

define('DDFM_ATTACHED', 'File attached');

define('DDFM_INVALIDEXT', 'Invalid file type:');

define('DDFM_UPLOADERR', 'Upload Error:');

define('DDFM_SERVERERR', '<p>Error sending message!</p>');

define('DDFM_GDERROR', '<p>GD not detected! GD is required for the image verification feature.</p>');


?>