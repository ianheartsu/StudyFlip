<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// translated by Valeriu Palos (valeriu@palos.ro)
// iso-8859-2 Romanian Language Settings


define('DDFM_SUBMITBUTTON', 'Trimite Mesaj');

define('DDFM_CREDITS', 'Script creat de');

define('DDFM_CONFIRMPASS', 'Confirm&#259;');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Erori la completare!');

define('DDFM_MAXCHARLIMIT', 'lungime maxim&#259; pentru ');

define('DDFM_MISSINGFIELD', 'Valoare obligatorie necompletat&#259; ');

define('DDFM_INVALIDINPUT', 'Valoare invalid&#259; pentru ');

define('DDFM_INVALIDEMAIL', 'Adres&#259; e-mail invalid&#259; pentru ');

define('DDFM_INVALIDURL', 'Adres&#259; URL invalid&#259; pentru ');

define('DDFM_NOMATCH', 'Valorile nu se potrivesc pentru ');

define('DDFM_MISSINGVER', 'Introduce&#355;i codul de verificare ');

define('DDFM_NOVERGEN', 'Nu a fost generat nici un cod de verificare');

define('DDFM_INVALIDVER', 'Codul de verificare este invalid');

define('DDFM_MISSINGFILE', 'Lipseste fi&#351;ierul obligatoriu ');

define('DDFM_FILETOOBIG', 'Fi&#351;ierul este prea mare: ');

define('DDFM_ATTACHED', 'Fi&#351;ier ata&#351;at ');

define('DDFM_INVALIDEXT', 'Tipul fi&#351;ierului este invalid: ');

define('DDFM_UPLOADERR', 'Eroare la upload: ');

define('DDFM_SERVERERR', '<p>Eroare la trimiterea mesajului!</p>');

define('DDFM_GDERROR', '<p>Biblioteca GD nu a fost detectat&#259;! Biblioteca GD este necesar&#259; pentru generarea codului de verificare.</p>');


?>