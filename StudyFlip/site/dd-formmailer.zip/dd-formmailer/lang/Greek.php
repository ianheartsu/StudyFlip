<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// translated by Theodore Paliouras
// iso-8859-7 Greek Language Settings


define('DDFM_SUBMITBUTTON', 'Αποστολή Email');

define('DDFM_CREDITS', 'Script by');

define('DDFM_CONFIRMPASS', 'Επιβεβαιώστε');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Σφάλμα!');

define('DDFM_MAXCHARLIMIT', 'Οριο χαρακτήρων για');

define('DDFM_MISSINGFIELD', 'Παρακαλούμε να συμπληρωθεί το υποχρεωτικό πεδίο ');

define('DDFM_INVALIDINPUT', 'Ακυρη εισαγωγή για');

define('DDFM_INVALIDEMAIL', 'Λάθος Email διεύθυνση για');

define('DDFM_INVALIDURL', 'Λάθος URL για');

define('DDFM_NOMATCH', 'Οι τομείς δεν ταιριάζουν με');

define('DDFM_MISSINGVER', 'Πληκτρολογείστε τον κωδικό επαλήθευσης');

define('DDFM_NOVERGEN', 'δεν έχει Κωδικό Επαλήθευσης');

define('DDFM_INVALIDVER', 'Λάθος Κωδικός Επαλήθευσης');

define('DDFM_MISSINGFILE', 'Απαραίτητη εισαγωγη  αρχείου');

define('DDFM_FILETOOBIG', 'Μη αποδεκτό μέγεθος αρχείου Error!:');

define('DDFM_ATTACHED', 'Φόρτωση του αρχείου');

define('DDFM_INVALIDEXT', 'Μη αποδεκτός τύπος αρχείου Error!:');

define('DDFM_UPLOADERR', 'Σφάλμα Φόρτωσης:');

define('DDFM_SERVERERR', '<p>Σφάλμα αποστολής του μηνύματος!</p>');

define('DDFM_GDERROR', '<p>GD δεν εμφανίστηκε το GD απαιτείται για την εικόνα του κωδικού επαλήθευσης!</p>');

?>