<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Vietnamese Language Settings


define('DDFM_SUBMITBUTTON', 'Gửi Email');

define('DDFM_CREDITS', 'Viết bởi');

define('DDFM_CONFIRMPASS', 'Xác nhận');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Lỗi!');

define('DDFM_MAXCHARLIMIT', 'vượt quá số ký tự cho phép cho');

define('DDFM_MISSINGFIELD', 'Thiếu dữ liệu bắt buộc ');

define('DDFM_INVALIDINPUT', 'Dữ liệu không hợp lệ với');

define('DDFM_INVALIDEMAIL', 'Địa chỉ email không hợp lệ với');

define('DDFM_INVALIDURL', 'URL(đường dẫn) không hợp lệ với');

define('DDFM_NOMATCH', 'Các trường dữ liệu không khớp với');

define('DDFM_MISSINGVER', 'Nhập mã xác thực');

define('DDFM_NOVERGEN', 'Không có mã xác thực nào được tạo ra');

define('DDFM_INVALIDVER', 'Mã xác thực không hợp lệ');

define('DDFM_MISSINGFILE', 'Thiếu tệp dữ liệu bắt buộc');

define('DDFM_FILETOOBIG', 'Tệp dữ liệu quá lớn:');

define('DDFM_ATTACHED', 'Tệp dữ liệu đã được đính kèm');

define('DDFM_INVALIDEXT', 'Kiểu tệp dữ liệu không hợp lệ:');

define('DDFM_UPLOADERR', 'Lỗi đính kèm tệp dữ liệu:');

define('DDFM_SERVERERR', '<p>Lỗi gửi tin nhắn!</p>');

define('DDFM_GDERROR', '<p>Không tìm thấy GD! GD là bắt buộc cho tính năng xác thực hình ảnh.</p>');


?>