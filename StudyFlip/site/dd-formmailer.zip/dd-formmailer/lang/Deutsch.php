<?php

/* Dagon Design Form Mailer v5
http://www.dagondesign.com
German Language Settings
German translation by Daniel Erb http://www.daniel-erb.de */


define('DDFM_SUBMITBUTTON', 'E-Mail Absenden');

define('DDFM_CREDITS', 'Plugin von');

define('DDFM_CONFIRMPASS', 'Best&auml;tigung');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Fehler!');

define('DDFM_MAXCHARLIMIT', 'Die maximale Anzahl von Zeichen ist erreicht');

define('DDFM_MISSINGFIELD', 'Pr&uuml;fen Sie folgende Angaben auf Richtigkeit / Vollst&auml;ndigkeit:');

define('DDFM_INVALIDINPUT', 'Falsche / Fehlende Eingabe:');

define('DDFM_INVALIDEMAIL', 'Falsche / Fehlende Eingabe der E-Mail Adresse:');

define('DDFM_INVALIDURL', 'Falsche / Fehlende URL-Angabe:');

define('DDFM_NOMATCH', 'Die folgenden Eintr&auml;ge sind falsch / unvollst&auml;ndig:');

define('DDFM_MISSINGVER', 'Geben Sie bitte den Zeichencode ein:');

define('DDFM_NOVERGEN', 'Es wurde kein Zeichencode generiert');

define('DDFM_INVALIDVER', 'Der Zeichencode wurde falsch eingegeben');

define('DDFM_MISSINGFILE', 'Die ben&ouml;tigte Datei fehlt');

define('DDFM_FILETOOBIG', 'Die angeh&auml;ngte Datei ist zu gro&szlig;:');

define('DDFM_ATTACHED', 'Datei angeh&auml;gt');

define('DDFM_INVALIDEXT', 'Falscher Datentyp:');

define('DDFM_UPLOADERR', 'Fehler beim &Uuml;bermitteln der Daten:');

define('DDFM_SERVERERR', '<p>Die Nachricht konnte nicht abgesendet werden!</p>');

define('DDFM_GDERROR', '<p>GD wurde nicht gefunden! GD  wird f&uuml;r die Generierung der Zeichencode-Abfrage ben&ouml;tigt.</p>');


?>