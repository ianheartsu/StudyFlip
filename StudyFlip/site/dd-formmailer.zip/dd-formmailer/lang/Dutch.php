<?php

/* Dagon Design Form Mailer v5
http://www.dagondesign.com
Dutch Language Settings
Dutch translation by Ton Hermans ton(at)gomac.nl */


define('DDFM_SUBMITBUTTON', 'E-Mail Versturen');

define('DDFM_CREDITS', 'Plugin van');

define('DDFM_CONFIRMPASS', 'Bevestig');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'foutmelding!');

define('DDFM_MAXCHARLIMIT', 'Het maximaal aantal tekens is bereikt');

define('DDFM_MISSINGFIELD', 'U heeft een verplicht veld niet ingevuld:');

define('DDFM_INVALIDINPUT', 'Verkeerde opgave voor:');

define('DDFM_INVALIDEMAIL', 'U email adres is niet correct:');

define('DDFM_INVALIDURL', 'De url is niet correct:');

define('DDFM_NOMATCH', 'Deze velden komen niet overeen:');

define('DDFM_MISSINGVER', 'Type de letters op de foto na:');

define('DDFM_NOVERGEN', 'Er werd geen foto code gegenereerd');

define('DDFM_INVALIDVER', 'De tekens op de foto zijn niet goed na getypt');

define('DDFM_MISSINGFILE', 'Er mist een verplicht veld');

define('DDFM_FILETOOBIG', 'Het bestand is te groot:');

define('DDFM_ATTACHED', 'Bijlage');

define('DDFM_INVALIDEXT', 'Verkeerde type bestand:');

define('DDFM_UPLOADERR', 'Upload fout:');

define('DDFM_SERVERERR', '<p>Het bericht kon niet verstuurd worden!</p>');

define('DDFM_GDERROR', '<p>GD niet gevonden! GD is nodig voor de foto verificatie.</p>');


?>