<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Danish Language Settings


define('DDFM_SUBMITBUTTON', 'Send Email');

define('DDFM_CREDITS', 'Script forfatter');

define('DDFM_CONFIRMPASS', 'Bekr�ft');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Fejl!');

define('DDFM_MAXCHARLIMIT', 'maksimal antal tegn for');

define('DDFM_MISSINGFIELD', 'Mangler obligatorisk oplysning');

define('DDFM_INVALIDINPUT', 'Ugyldig indtastning for');

define('DDFM_INVALIDEMAIL', 'Ugyldig emailadresse for');

define('DDFM_INVALIDURL', 'Ugyldig URL for');

define('DDFM_NOMATCH', 'Indtastede data passer ikke for');

define('DDFM_MISSINGVER', 'Indtast verifikationskode');

define('DDFM_NOVERGEN', 'Verifikationskode ikke vist');

define('DDFM_INVALIDVER', 'Ugyldig verifikationskode');

define('DDFM_MISSINGFILE', 'Mangler obligatorisk mappe');

define('DDFM_FILETOOBIG', 'Mappe for stor:');

define('DDFM_ATTACHED', 'Mappe vedlagt');

define('DDFM_INVALIDEXT', 'Ugyldig mappetype:');

define('DDFM_UPLOADERR', 'Upload fejl:');

define('DDFM_SERVERERR', '<p>Fejl under afsendelse!</p>');

define('DDFM_GDERROR', '<p>GD ikke detekteret! GD er n�dvendig for verifikationskode-funktionen.</p>');


?>