<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Swedish Language Settings


define('DDFM_SUBMITBUTTON', 'Skicka');

define('DDFM_CREDITS', 'Script av');

define('DDFM_CONFIRMPASS', 'Bekr�fta');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Ett fel har uppst�tt!');

define('DDFM_MAXCHARLIMIT', 'max antal tecken f�r');

define('DDFM_MISSINGFIELD', 'Missing required field ');

define('DDFM_INVALIDINPUT', 'Felaktig inmatning f�r');

define('DDFM_INVALIDEMAIL', 'Felaktig E-postadress f�r');

define('DDFM_INVALIDURL', 'Felaktig webbadress f�r');

define('DDFM_NOMATCH', 'F�lten �verensst�mmer inte f�r');

define('DDFM_MISSINGVER', 'Skriv in verifieringskod');

define('DDFM_NOVERGEN', 'Ingen verifieringskod har skapats');

define('DDFM_INVALIDVER', 'Felaktig verifieringskod');

define('DDFM_MISSINGFILE', 'Obligatorisk fil saknas');

define('DDFM_FILETOOBIG', 'Filen �r f�r stor:');

define('DDFM_ATTACHED', 'Bifogad fil');

define('DDFM_INVALIDEXT', 'Felaktig filtyp:');

define('DDFM_UPLOADERR', 'Ett fel uppstod vid uppladdningen:');

define('DDFM_SERVERERR', '<p>Ett fel uppstod n�r meddelandet skulle skickas!</p>');

define('DDFM_GDERROR', '<p>GD saknas! GD kr�vs f�r att bildidentifiering ska kunna anv�ndas.</p>');


?>