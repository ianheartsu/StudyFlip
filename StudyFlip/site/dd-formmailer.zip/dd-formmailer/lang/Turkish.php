<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com
// Turkish translation by Onur ERKAN onur(at)onurerkan.com


// T�rk�e Dil Ayarlar� 



define('DDFM_SUBMITBUTTON', 'G�nder');

define('DDFM_CREDITS', 'Destekleyen');

define('DDFM_CONFIRMPASS', 'Onay Kodu');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Hata!');

define('DDFM_MAXCHARLIMIT', 'Karakter Limitini A�t�n�z');

define('DDFM_MISSINGFIELD', 'Doldurulmas� Gereken Alanlar ');

define('DDFM_INVALIDINPUT', 'Hatal� Giri�');

define('DDFM_INVALIDEMAIL', 'Hatali E-Mail adresi');

define('DDFM_INVALIDURL', 'Hatali URL');

define('DDFM_NOMATCH', 'Alanlar Uyu�muyor');

define('DDFM_MISSINGVER', 'Onay Kodunu Giriniz');

define('DDFM_NOVERGEN', 'Onay Kodu Olu�turulmad�');

define('DDFM_INVALIDVER', 'Hatal� Onay kodu');

define('DDFM_MISSINGFILE', 'Dosya Eksik');

define('DDFM_FILETOOBIG', 'Dosya �ok B�y�k:');

define('DDFM_ATTACHED', 'Dosya Eklendi');

define('DDFM_INVALIDEXT', 'Yanl�� Dosya T�r�');

define('DDFM_UPLOADERR', 'Y�kleme Hatas�:');

define('DDFM_SERVERERR', '<p>Mesaj G�nderirken Hata Olu�tu!</p>');

define('DDFM_GDERROR', '<p>Onaylama Sistemi i�in GD K�t�phanesini Kurunuz</p>');


?>