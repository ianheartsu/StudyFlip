<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Catalan Language Settings


define('DDFM_SUBMITBUTTON', 'Enviar missatge electr&ograve;nic');

define('DDFM_CREDITS', 'Script per');

define('DDFM_CONFIRMPASS', 'Confirmaci&oacute;');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Errors!');

define('DDFM_MAXCHARLIMIT', 'limit de car&agrave;cters per');

define('DDFM_MISSINGFIELD', 'Camp necessari desaparegut ');

define('DDFM_INVALIDINPUT', 'Entrada no v&agrave;lida per a');

define('DDFM_INVALIDEMAIL', 'Adre&ccedil;a electr&ograve;nica no v&agrave;lida per a');

define('DDFM_INVALIDURL', 'URL no v&agrave;lida per a');

define('DDFM_NOMATCH', 'Els camps no coinsideixen per a');

define('DDFM_MISSINGVER', 'Introdueix el codi de verificaci&oacute;');

define('DDFM_NOVERGEN', 'No s\'ha generat el codi de verificaci&oacute;');

define('DDFM_INVALIDVER', 'El codi de verificaci&oacute; no &eacute;s correcte');

define('DDFM_MISSINGFILE', 'Camp necessari desaparegut');

define('DDFM_FILETOOBIG', 'Fitxer massa gran:');

define('DDFM_ATTACHED', 'Fitxer adjuntat');

define('DDFM_INVALIDEXT', 'El tipus de fitxer no &eacute;s v&agrave;lid:');

define('DDFM_UPLOADERR', 'Error de pujada:');

define('DDFM_SERVERERR', '<p>Error al enviar el missatge!</p>');

define('DDFM_GDERROR', '<p>GD no detectat! Es requereix GD per a la funci&oacute; de verificaci&oacute; de la imatge.</p>');


?>