<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// French Language Settings


define('DDFM_SUBMITBUTTON', 'Envoyer');

define('DDFM_CREDITS', 'Ecrit par');

define('DDFM_CONFIRMPASS', 'Confirmer');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Erreurs!');

define('DDFM_MAXCHARLIMIT', 'nombre limit&eacute; de caract&egrave;res');

define('DDFM_MISSINGFIELD', 'Champ requis manquant ');

define('DDFM_INVALIDINPUT', 'Entr&eacute;e invalide pour');

define('DDFM_INVALIDEMAIL', 'Adresse mail invalide pour');

define('DDFM_INVALIDURL', 'URL invalide pour');

define('DDFM_NOMATCH', 'Champs ne correspondant pas pour');

define('DDFM_MISSINGVER', 'Entrez le code de v&eacute;rification');

define('DDFM_NOVERGEN', 'Code de v&eacute;rification non g&eacute;n&eacute;r&eacute;');

define('DDFM_INVALIDVER', 'Code de v&eacute;rification invalide');

define('DDFM_MISSINGFILE', 'Fichier requis manquant');

define('DDFM_FILETOOBIG', 'Fichier trop volumineux:');

define('DDFM_ATTACHED', 'Fichier attach&eacute;');

define('DDFM_INVALIDEXT', 'Type de fichier invalide:');

define('DDFM_UPLOADERR', 'Erreur d\'envoi:');

define('DDFM_SERVERERR', '<p>Erreur &agrave; l\'envoi du message!</p>');

define('DDFM_GDERROR', '<p>GD n\'est pas d&eacute;tect&eacute; ! GD est requis pour la fonctionalit&eacute; de l\'image de v&eacute;rification.</p>');


?>