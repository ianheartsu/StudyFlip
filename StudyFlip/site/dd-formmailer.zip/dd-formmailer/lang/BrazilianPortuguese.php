<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com
// Configura��es Para Portugu�s do Brasil
// Script traduzido para o Portugu�s do Brasil por Fl�vio Ara�jo
//http://flaviowd.wordpress.com


define('DDFM_SUBMITBUTTON', 'Enviar Email');

define('DDFM_CREDITS', 'Script desenvolvido por');

define('DDFM_CONFIRMPASS', 'Confirmar');

define('DDFM_REQUIREDTAG', '*');

define('DDFM_ERRORMSG', 'Erros!');

define('DDFM_MAXCHARLIMIT', 'Limite de caracteres para');

define('DDFM_MISSINGFIELD', 'Preencha todos os campos ');

define('DDFM_INVALIDINPUT', 'Entrada de dados inv&aacute;lida para');

define('DDFM_INVALIDEMAIL', 'Endere�o de email inv&aacute;lido para');

define('DDFM_INVALIDURL', 'URL inv&aacute;lida para');

define('DDFM_NOMATCH', 'Tipo de arquivo n&atilde;o aceito para');

define('DDFM_MISSINGVER', 'Digite o c&oacute;digo de verifica&ccedil;&atilde;o');

define('DDFM_NOVERGEN', 'O c&oacute;digo de verifica&ccedil;&atilde;o n&atilde;o foi gerado');

define('DDFM_INVALIDVER', 'C&oacute;digo de verifica&ccedil;&atilde;o inv&aacute;lido');

define('DDFM_MISSINGFILE', '&Eacute; necess&aacute;rio insirir um arquivo');

define('DDFM_FILETOOBIG', 'O arquivo &eacute; muito grande:');

define('DDFM_ATTACHED', 'Arquivo Anexado');

define('DDFM_INVALIDEXT', 'Tipo de Arquivo Inv&aacute;lido:');

define('DDFM_UPLOADERR', 'Erro ao Enviar o Arquivo:');

define('DDFM_SERVERERR', '<p>Erro ao Enviar a Mensagem!</p>');

define('DDFM_GDERROR', '<p>GD n&atilde;o detectada! GD &eacute; necess&aacute;rio para gerar as imagens de verifica&ccedil;&atilde;o.</p>');


?>