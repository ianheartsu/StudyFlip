<?php

// Dagon Design Form Mailer v5
// http://www.dagondesign.com

// Spanish Language Settings


define('DDFM_SUBMITBUTTON', 'Enviar Email');
define('DDFM_CREDITS', 'Script por');
define('DDFM_CONFIRMPASS', 'Confirmar');
define('DDFM_REQUIREDTAG', '*');
define('DDFM_ERRORMSG', '¡Errores!');
define('DDFM_MAXCHARLIMIT', 'límite de caracteres para ');
define('DDFM_MISSINGFIELD', 'Falta un campo requerido ');
define('DDFM_INVALIDINPUT', 'Entrada no válida para');
define('DDFM_INVALIDEMAIL', 'Dirección de email no válida para');
define('DDFM_INVALIDURL', 'URL no válida para');
define('DDFM_NOMATCH', 'Los campos no coinciden para');
define('DDFM_MISSINGVER', 'Introduzca el código de verificación');
define('DDFM_NOVERGEN', 'No se generó ningún código de verificación');
define('DDFM_INVALIDVER', 'Código de verificación no válido');
define('DDFM_MISSINGFILE', 'Falta un fichero requerido');
define('DDFM_FILETOOBIG', 'El fichero es demasiado grande:');
define('DDFM_ATTACHED', 'Fichero adjunto');
define('DDFM_INVALIDEXT', 'Tipo de fichero no válido:');
define('DDFM_UPLOADERR', 'Error en la transferencia:');
define('DDFM_SERVERERR', '<p>¡Error enviando el mensaje!</p>');
define('DDFM_GDERROR', '<p>¡No se detecto la libería GD! Esta es requerida para crear la imagen de verificación.</p>');

?>