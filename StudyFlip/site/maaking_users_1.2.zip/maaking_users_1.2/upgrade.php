<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed             \\
Version     :  1.2                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    26-APR-2008               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Skype      :   maaking                    \\
                                          \\
===========================================\
------------------------------------------*/

include ("functions.php");
global $prefix,$databse_name;

$sql1 = mysql_query(" RENAME TABLE ".$databse_name.".".$prefix."_setupme TO ".$databse_name.".".$prefix."_options ; ");

$sql2 = mysql_query(" ALTER TABLE ".$prefix."_options ADD `validate` TINYINT( 1 ) NOT NULL ; ");

$sql3 = mysql_query(" ALTER TABLE ".$prefix."_users ADD `isactive` TINYINT( 1 ) NOT NULL DEFAULT '0'; ");

$sql4 = mysql_query(" ALTER TABLE ".$prefix."_users ADD `code` VARCHAR( 15 ) NOT NULL ; ");

echo "<h3><font color=green>Upgrade done. Please delete this file.</font>";

?>
