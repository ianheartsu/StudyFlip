<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed             \\
Version     :  1.2                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    26-APR-2008               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Skype      :   maaking                    \\
                                          \\
===========================================\
------------------------------------------*/

if (eregi("header.php", $_SERVER['SCRIPT_NAME'])) {
    Header("Location: index.php"); die();
}

global $site_name, $site_url, $site_info, $site_email, $tmp_header;

echo "<html dir=\""._LTR_RTL."\">\n"
     ."<head>\n"
     ."<meta name=\"generator\" content=\"microsoft frontpage 6.0\">\n"
     ."<meta name=\"progid\" content=\"frontpage.editor.document\">\n"
     ."<meta name=\"author\" content=\"mohammed ahmed m[at]maaking.com\">\n"
     ."<meta http-equiv=\"content-type\" content=\"text/html; charset="._CHARSET."\">\n"
     ."<title>$site_name</title>\n"
     ."<link rel=\"stylesheet\" href=\"style.css\" type=\"text/css\">\n"
     ."</head>\n\n";
     //print the header template
     echo "$tmp_header";
?>
