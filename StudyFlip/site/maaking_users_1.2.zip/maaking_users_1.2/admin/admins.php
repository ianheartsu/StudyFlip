<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed(M@@king)    \\
Version     :  1.1                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    18-SEP-2006               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Mobile/SMS :   00972-599-622235           \\
                                          \\
===========================================\
------------------------------------------*/

include ("../functions.php");


if (is_logged_in_admin($admin)) {


function load_admins(){
        global $db,$fullname,$admin_name,$password,$email,$admin_taken_err,$email_taken_err;

  include ('header.php');
  
   nav_menu();

echo"<center><font class=title>Manage Admins</font>
<br>
<table border=1 bordercolor='#c0c0c0' width='80%'>
            <tr>
                <td bgcolor='#c0c0c0'>ID</td>
                <td bgcolor='#c0c0c0'>Admin</td>
                <td bgcolor='#c0c0c0'>Full Name</td>
                <td bgcolor='#c0c0c0'>Email</td>
                <td bgcolor='#c0c0c0'>Options</td>
            </tr>";
        $result = mysql_query("SELECT * from maaking_admin");
        while($myrow = mysql_fetch_array($result)){


            echo "<tr>
                 <td>&nbsp;$myrow[adminid]</td>
                 <td>&nbsp;$myrow[fullname]</td>
                 <td>&nbsp;$myrow[admin_name]</td>
                 <td>&nbsp;$myrow[email]</td>
                 <td>&nbsp;[<a href=admins.php?maa=edit_admins&adminid=$myrow[adminid]>Edit</a>]
                  [<a href=\"javascript:jsdel('admins.php?maa=del_admins&adminid=$myrow[adminid]')\">"._DEL."</a>]
                 </td>
                 </tr>";
        }

echo "</table>";


echo "<hr>
          <font class=title>Add Admin</font>
          <form method=\"POST\" enctype=\"multipart/form-data\" action=\"admins.php\">
        <table border=0>
        <tr>
            <td>Fullname</td>
            <td>&nbsp;<input type=\"text\" name=\"fullname\" value=\"$fullname\" size=\"20\"></td>
        </tr>
        <tr>
            <td>Admin Username</td>
             <td>&nbsp;<input type=\"text\" name=\"admin_name\" value=\"$admin_name\" size=\"20\"> Username $admin_taken_err</td>
        </tr>
        <tr>
            <td>Password</td>
             <td>&nbsp;<input type=\"password\" name=\"password\" value=\"$password\" size=\"20\"></td>
        </tr>
         <tr>
            <td>Email</td>
             <td>&nbsp;<input type=\"text\" name=\"email\" value=\"$email\" size=\"20\"> $email_taken_err</td>
        </tr>
        <tr>
             <td>&nbsp;</td>
             <td><input type=\"hidden\" name=\"maa\" value=\"do_add_admins\">
                 <input type=\"submit\" value=\"Add\" name=\"B1\"></p></form>
             </td>
        </tr>
</table>";

 include ('footer.php');

}

function do_add_admins(){
     global  $db,$prefix,$fullname,$admin_name,$password,$email,$admin_taken_err,$email_taken_err;

     if ((!$fullname) or (!$admin_name)  or (!$password)){

        echo "Error: All Feilds are required!";

     exit();
     }

    //--nothing empty? everything is okay? lets do the register.
    $email_check = $db->sql_numrows($db->sql_query("SELECT email FROM ".$prefix."_admin WHERE email='$email'"));
    $admin_check = $db->sql_numrows($db->sql_query("SELECT admin_name FROM ".$prefix."_admin WHERE admin_name='$admin_name'"));
        if(($email_check > 0) || ($admin_check > 0)){
               //define error message for usage in multi plces.
               $exist_msg= "<font class=\"error\">"._ALREADY_TAKEN."</font>";

               if($email_check > 0){
                  $email_taken_err =  $exist_msg;
                  unset($email);
               }

               if($admin_check > 0){
                  $admin_taken_err =  $exist_msg;
                  unset($admin_name);
               }

               //if the username or email already been taken load the form and print errors.
               load_admins();

               exit();
        }
    $password = md5($password);
    
    $sql =  mysql_query("INSERT INTO ".$prefix."_admin (fullname,admin_name,password,email,regdate) VALUES ('$fullname','$admin_name','$password','$email',NOW())") or die ("Error Adding Mod: ". mysql_error());

    msg_redirect(""._ADDED_SUCCESS."","admins.php","2");
    
}

function edit_admins() {
	global $db,$adminid,$prefix;

   include ('header.php');

   nav_menu();

        $result = mysql_query("SELECT * from maaking_admin WHERE adminid='$adminid'");
        $myrow = mysql_fetch_array($result);



echo "<center><font class=title>Edit Admin</font>";

   echo "<form method=\"POST\" enctype=\"multipart/form-data\" action=\"admins.php\">
        <table border=0>
        <tr>
            <td>Full Name</td>
            <td>&nbsp;<input type=\"text\" name=\"fullname\" value=\"$myrow[fullname]\" size=\"20\"></td>
        </tr>
        <tr>
            <td>Admin Username</td>
             <td>&nbsp;<input type=\"text\" readonly name=\"admin_name\" value=\"$myrow[admin_name]\" size=\"20\"></td>
        </tr>
        <tr>
            <td>Password</td>
             <td>&nbsp;<input type=\"password\" name=\"password\" value=\"\" size=\"20\"> enter new pass for change</td>
        </tr>
        <tr>
            <td>Email</td>
             <td>&nbsp;<input type=\"text\" name=\"email\" value=\"$myrow[email]\" size=\"20\"></td>
        </tr>
        <tr>
             <td>&nbsp;</td>
             <td>
                <input type=\"hidden\" name=\"adminid\" value=\"$myrow[adminid]\">
                <input type=\"hidden\" name=\"maa\" value=\"do_edit_admins\">
                <input type=\"submit\" value=\"Save Changes\" name=\"B1\"></p></form>
            </td>
         </tr>
</table>";

    include ('footer.php');
}


function do_edit_admins(){
      global  $db,$prefix,$fullname,$admin_name,$password,$email,$adminid;

      if ($password == ""){
      $sql =  mysql_query("UPDATE  maaking_admin SET  fullname='$fullname',admin_name='$admin_name',email='$email' where adminid='$adminid'") or die ("Error Editing admins: ". mysql_error());
      }else{
      $password = md5($password);
      $sql =  mysql_query("UPDATE  maaking_admin SET  fullname='$fullname',admin_name='$admin_name',password='$password',email='$email' where adminid='$adminid'") or die ("Error Editing admins: ". mysql_error());
      }
      
      msg_redirect(""._EDITED_SUCCESS."","admins.php","2");
}
function del_admins(){
      global  $db,$prefix,$adminid;

      if ($adminid == 1){
          die("You Cannot delete the Main Admin");
      }else{
       $sql =  mysql_query("delete from  maaking_admin where adminid='$adminid'") or die ("Error del admins: ". mysql_error());
      }
      msg_redirect(""._DELETED_SUCCESS."","admins.php","2");
}

switch($maa) {

             default:
             load_admins();
             break;


       case "do_add_admins":
             do_add_admins();
             break;

       case "del_admins":
             del_admins();
             break;
             
       case "edit_admins":
             edit_admins();
             break;
       
      	case "do_edit_admins":
             do_edit_admins();
             break;

        case "del_admins":
             del_admins();
             break;
}

//////////////////////////////////
//if the admin is not logged in.
}else{
      $error_msg = "<font class=\"error\">"._ADMIN_LOGIN_ERR."</font>";
      unset($admin_name);
      unset($password);

      msg_redirect($error_msg,"index.php","1");
      exit();
}
?>
