<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed(M@@king)    \\
Version     :  1.1                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    18-SEP-2006               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Mobile/SMS :   00972-599-622235           \\
                                          \\
===========================================\
------------------------------------------*/
include ("../functions.php");

// the Default function.
//note for functions: if you want to include a value of some variables inside the funtions,
//then you have to GLOBAL it first.
function index($admin) {
     global $db, $prefix;

     //check if the user is logged in or not.
     if (is_logged_in_admin($admin)) {
          include("header.php");
          //if the user is logged in then read the cookies.
          $cookie_read = explode("|", base64_decode($admin));
          //define variables to hold cookie values.
          $adminid = $cookie_read[0];
          $admin_name = $cookie_read[1];
          $password = $cookie_read[2];
          $ipaddress = $cookie_read[3];
          $lastlogin_date = $cookie_read[4];
          $lastlogin_time = $cookie_read[5];
          
          //print wilcome message
          echo "Welcome <b>$admin_name</b>, Last login from: [$ipaddress] on [$lastlogin_date @ $lastlogin_time] (<a href=index.php?maa=Logout>Logout</a>)";
          echo "<br><br><br><br>";

          nav_menu();

          include("footer.php");
     }else{
         //if the user is not logged in then show the login form.
         //  header("Location: index.php?maa=Login");  die();
         include("header.php");
         login_form();
         include("footer.php");
    }
}
################################################################################
#------------------------------------------------------------------------------#
#  login
#------------------------------------------------------------------------------#
################################################################################
//the login form
function login_form(){
         global $admin_name,$admin_err,$pass_err,$error_msg;

echo "<center><font class=\"title\">Please enter your admin name and password to log in.</font></center>\n";
echo "
<center>
      <form method=\"POST\" action=\"index.php\" name=\"loginform\">
        <table border=\"0\" cellspacing=\"2\" cellpadding=\"4\">
        <tr>
            <td bgcolor=\"#E2E2E2\">admin name: </td>
            <td bgcolor=\"#E2E2E2\"><input type=\"text\" name=\"admin_name\" value=\"$admin_name\" size=\"11\"> $admin_err</td>
        </tr>
        <tr>
            <td bgcolor=\"#E2E2E2\">Password: </td>
            <td bgcolor=\"#E2E2E2\"><input type=\"password\" name=\"password\" size=\"11\"> $pass_err</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td> <input type=\"hidden\" name=\"maa\" value=\"do_login\">
                 <input type=\"submit\" value=\"Login\"></p>
            </td>
        </tr>
        </table> $error_msg
      </form> [ <a href=\"index.php?maa=Forgot_pwd\">Forgot password?.</a> ]<br><br>";
}

//a login function to call the login form.
function Login(){
        include("header.php");
        login_form();
        include("footer.php");
}

//this function will do the login for you.
function do_login(){
         global $prefix,$db,$admin_name,$password, $remember, $admin_err,$pass_err,$error_msg,$REMOTE_ADDR;


         //check admin name and password fields.
         if((!$admin_name) || (!$password)){
                include("header.php");
                $reqmsg= "(<font class=error>Required!</font>)";

                if(trim(empty($admin_name))){
                   $admin_err= $reqmsg;
                }
                if(empty($password)){
                   $pass_err= $reqmsg;
                }
                //$error_msg = "<center><font class=\"error\">Error:</font></center>\n";
                login_form();
                include("footer.php");
                exit();
         }

         //encyrpt  password for more Security
         $md5_pass = md5($password);
         $sql = mysql_query("SELECT * FROM ".$prefix."_admin WHERE admin_name='$admin_name' AND password='$md5_pass'");
         $login_check = mysql_num_rows($sql);
         ///////////////////////////////////////////////////////////////////////
         if($login_check > 0){
            while($row = mysql_fetch_array($sql)){

                 $adminid = $row['adminid'];
                 $admin_name = $row['admin_name'];
                 $password = $row['password'];
                 $ipaddress = $row['ipaddress'];

                 $lastlogin = explode(" ", $row['lastlogin']);
                 $lastlogin_date =  $lastlogin[0];
                 $lastlogin_time = $lastlogin[1];

                 $info = base64_encode("$adminid|$admin_name|$password|$ipaddress|$lastlogin_date|$lastlogin_time");

                 setcookie("admin","$info",0);

                 mysql_query("UPDATE ".$prefix."_admin SET ipaddress='$REMOTE_ADDR', lastlogin=NOW() WHERE adminid='$adminid'") or die (mysql_error());

                 msg_redirect("Login success please wait..........","index.php","2");
                 //header("Location: index.php");
            }//end while
         }else{
                //include("header.php");
                $error_msg = "<font class=error>Login error. Please check admin name/password.</font>";
                unset($admin_name);
                unset($password);
                include("header.php");
                login_form();
                include("footer.php");
                exit();
         }
}


################################################################################
#------------------------------------------------------------------------------#
#  logout
#------------------------------------------------------------------------------#
################################################################################
function Logout($admin) {


    unset($admin);
    unset($cookie);

    setcookie("admin", false);
    $admin = "";
    header("Location: index.php");
    
}

################################################################################
#------------------------------------------------------------------------------#
#  Forgot Password
#------------------------------------------------------------------------------#
################################################################################
function Forgot_pwd_form(){
global $error_msg;
echo "<center><font class=\"title\">Send me a new password</font>
<form method='POST' action='index.php'>
<table border='0' cellpadding='4'>
        <tr>
                <td bgcolor='#E2E2E2'>admin name:</td>
                <td bgcolor='#E2E2E2'><input type='text' name='admin_name' size='11'></td>
        </tr>
        <tr>
                <td bgcolor='#E2E2E2'>Email:</td>
                <td bgcolor='#E2E2E2'><input type='text' name='email' size='11'></td>
        </tr>
        <tr>
                <td>&nbsp;</td>
                    <td>
                    <input type='hidden' name='maa' value='do_Forgot_pwd'>
                    <input type='submit' value='Send password'></p>
                </td>
        </tr>
</table><center>$error_msg</center>
</form>";
}

function Forgot_pwd(){
         global $admin, $prefix, $db;

         include("header.php");
         Forgot_pwd_form();
         include("footer.php");
}

function do_Forgot_pwd(){
         global $admin, $prefix, $db, $email, $admin_name, $error_msg, $site_name ,$site_email, $site_url;

         $result = mysql_query("SELECT * FROM ".$prefix."_admin WHERE admin_name='$admin_name' AND email='$email'");
         $check = mysql_num_rows($result);
         if($check == 1){

         function new_pwd() {
                  $chars = "abchefghjkmnpqrstuvwxyz0123456789";
                  srand((double)microtime()*1000000);
                  $i = 0;
                  while ($i <= 7) {
                            $num = rand() % 33;
                            $tmp = substr($chars, $num, 1);
                            $pwd = $pwd . $tmp;
                            $i++;
                  }
                  return $pwd;
         }
         $new_pwd = new_pwd();
         $md5_password = md5($new_pwd);
         $sql = mysql_query("UPDATE ".$prefix."_admin SET password='$md5_password' WHERE email='$email'");






$subject = "New password";
$message = "
Hello $admin_name,

You are receiving this email because you have (or someone pretending to be you has) requested a new password be sent for your account on $site_name.

Here it is below.
--------------------------
admin name: $admin_name
Password: $new_pwd
--------------------------
You may login below:
$site_url

You can of course change this password yourself via the profile page. If you have any difficulties please contact the webmaster.

--
-Thanks
$site_name

This email was automatically generated.
Please do not respond to this email or it will ignored.";

         mail($email,$subject,$message, "FROM: $site_name <$site_email>");

         include("header.php");
         echo "Your New Pass has been emailed to your email.";
         echo "<br>please wait...";
         include("footer.php");


         }else{
                include("header.php");
                Forgot_pwd_form();
                echo "<center><font class=\"error\">Error: Wrong admin name/email</font></center><br>";
                include("footer.php");
         }
}


################################################################################
#------------------------------------------------------------------------------#
#  a switch  for switching between functions
#------------------------------------------------------------------------------#
################################################################################
switch ($maa){

       case "Forgot_pwd":
            Forgot_pwd();
            break;

       case "do_Forgot_pwd":
            do_Forgot_pwd();
            break;
            
       case "Register":
            Register();
            break;

       case "do_Register":
            do_Register();
            break;
            
       case "Logout":
            Logout($admin);
            break;
            
       case "Login":
            Login();
            break;

       case "do_login":
            do_login();
            break;

       Default:
               index($admin);
               Break;
}
?>
