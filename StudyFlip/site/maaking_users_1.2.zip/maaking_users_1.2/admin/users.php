<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed(M@@king)    \\
Version     :  1.1                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    18-SEP-2006               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Mobile/SMS :   00972-599-622235           \\
                                          \\
===========================================\
------------------------------------------*/
include ("../functions.php");
if (is_logged_in_admin($admin)) {

function ListUsers(){
         global $db, $prefix, $page;

         include("header.php");

         $users_per_page = "20";
         
         if (!isset($page) or $page=="") $page=1;
         $nexlimit = $page * $users_per_page - $users_per_page;

         $result = mysql_query("SELECT * FROM ".$prefix."_users ORDER BY userid DESC limit $nexlimit,$users_per_page");

         $result_all_rows = mysql_query("SELECT * FROM ".$prefix."_users");

         $totalrows = mysql_num_rows($result_all_rows);

         nav_menu();

         echo "<table border=\"1\" width=\"100%\" id=\"table1\">
	     <tr>
		<td colspan=\"5\" align=\"center\">Listing All Users ($totalrows)</td>
	     </tr>
	     <tr>
		<td align=\"center\">User ID</td>
		<td>Username</td>
		<td>User Email</td>
		<td>User Full Name</td>
		<td align=\"center\">Options</td>
	     </tr>";
         while ($row = mysql_fetch_array($result)){

              $userid = $row['userid'];
              $username = $row['username'];
              $email = $row['email'];
              $fullname = $row['fullname'];
              $site = $row['site'];
              $country = $row['country'];
              $city = $row['city'];
              $tel = $row['tel'];
              $profile = $row['profile'];
        
              echo "<tr>
		    <td align=\"center\">$userid</td>
		    <td>$username</td>
		    <td><a href=\"users.php?action=SendEmail&email=$email&username=$username\">$email</td>
		    <td>$fullname</td>
		    <td align=\"center\">[<a href=\"users.php?action=EditUser&userid=$userid\">Edit/View</a>]
                    [ <a href=\"javascript:jsdel('users.php?action=delUser&userid=$userid')\">Del</a> ]
                    </td>

                  </tr>";
         }//end while

         echo "</table>";
         // get pages:
         $totpages = ceil($totalrows/$users_per_page);
         for ($i=1;$i<=$totpages;$i++) {
	    if ($i==$page) {
		$pages .= " $i ";
	    } else {
		$pages .= " <a href=\"users.php?action=ListUsers&page=$i\">$i</a> ";
	    }
         }
         echo "<br><center>Pages: $pages <br>";

         include("footer.php");
}

function EditUser(){
         global $userid;
         
         include("header.php");
         EditUserForm();
         include("footer.php");
}

function EditUserForm(){
         global $db,$prefix,$userid,$username,$password,$email,$fullname,$site,$country,$city,$tel,$profile,$user_taken_err,$email_taken_err;

         nav_menu();
         
         $result = mysql_query("SELECT * FROM ".$prefix."_users WHERE userid='$userid'");
         $row = mysql_fetch_array($result);

         $userid = $row['userid'];
         $username = $row['username'];
         $email = $row['email'];
         $fullname = $row['fullname'];
         $site = $row['site'];
         $country = $row['country'];
         $city = $row['city'];
         $tel = $row['tel'];
         $profile = $row['profile'];
         
         echo "<center><font class=\"title\">Edit the User: [$username] </font></center><br>\n";
         echo "<center>Fields marked with a * are required.
               <form name=\"EditMyInfoForm\" method=\"POST\" action=\"users.php\">
               <table align=\"center\" border=\"1\" width=\"500\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\">
		<tr>
			<td  width=\"100\" align=\"right\">Username:</td>
			<td><input type=\"text\" disabled=\"true\" name=\"username\" size=\"18\" value=\"$username\"></td>
		</tr>
		<tr>
			<td align=\"right\">Email:</td>
			<td><input type=\"text\" name=\"email\" size=\"27\" value=\"$email\">  * $email_taken_err</td>
		</tr>
		<tr>
			<td align=\"right\">Full Name:</td>
			<td><input type=\"text\" name=\"fullname\" size=\"27\" value=\"$fullname\"></td>
		</tr>
		<tr>
			<td align=\"right\">Website:</td>
			<td><input type=\"text\" name=\"site\" size=\"27\" value=\"$site\"> eg. http://www.site.com</td>
		</tr>
                <tr>
			<td align=\"right\">Country:</td>
			<td><input type=\"text\" name=\"country\" size=\"27\" value=\"$country\"></td>
		</tr>
		<tr>
			<td align=\"right\">City:</td>
			<td><input type=\"text\" name=\"city\" size=\"27\" value=\"$city\"></td>
		</tr>
		<tr>
			<td align=\"right\">Tel/Mobile:</td>
			<td><input type=\"text\" name=\"tel\" size=\"27\" value=\"$tel\"></td>
		</tr>
		<tr>
			<td align=\"right\">Profile:</td>
			<td><textarea rows=\"5\" name=\"profile\" cols=\"30\">$profile</textarea></td>
		</tr>
                <tr>
			<td>&nbsp;</td>
			<td> <input type=\"hidden\" name=\"userid\" value=\"$userid\">
                             <input type=\"hidden\" name=\"action\" value=\"do_EditUser\">
                             <input type=\"submit\" value=\"Save Changes\"></td>
		</tr>
	       </table></form>";


}
function delUser(){
          global $db, $prefix, $userid;
          
          $result = mysql_query("delete from ".$prefix."_users WHERE userid='$userid'");



          include("header.php");
          echo "<div align=\"center\" class=\"div\">User has been deleted. <br>Please wait ...</div>";
          echo "<META HTTP-EQUIV=Refresh CONTENT=\"2; URL=users.php\">";
          include("footer.php");
          
          
}
function do_EditUser(){
          global $db, $prefix, $userid, $email, $fullname, $email_taken_err;
          global $site, $country, $city, $tel, $profile;
          global $site_name, $site_email, $site_url;


          //this function will check fields incase of javascript not working.
          if(trim(empty($email))){
             //print the error message and load the form.
             include("header.php");

             EditUserForm();
             echo "<center><font class=\"error\">Error: Please fill all fields.</font></center>\n";
             include("footer.php");
             exit();
          }


          /*--nothing empty? everything is okay? lets do the changes--*/
          $sql_email_check = mysql_query("SELECT email FROM ".$prefix."_users WHERE email='$email' AND userid!='$userid'") or die ("Error: ". mysql_error());
          $email_check = mysql_num_rows($sql_email_check);
          //define error message for usage in multi plces.
          $exist_msg = "<font class=\"error\">(The email $email: Already Taken!.)</font>";

          if($email_check == 1){
                  $email_taken_err =  $exist_msg;
                  unset($email);
                  //if the email already been taken load the form and print errors.
                  include("header.php");
                  EditUserForm();
                  include("footer.php");
                  exit();
          }

          $result = mysql_query("UPDATE ".$prefix."_users
                                        SET email='$email',
                                        fullname='$fullname',
                                        site='$site',
                                        country='$country',
                                        city='$city',
                                        tel='$tel',
                                        profile='$profile'
                                        WHERE userid='$userid'");


          include("header.php");
          echo "<div align=\"center\" class=\"div\">Your information has been successfully changed. <br>Please wait ...</div>";
          echo "<META HTTP-EQUIV=Refresh CONTENT=\"3; URL=users.php\">";
          include("footer.php");

}
function SendEmail(){
         include("header.php");
         global $db, $prefix, $email, $username, $site_name, $site_email, $site_url;
         
         nav_menu();
         
         echo "<form method=\"POST\" action=\"users.php\">
               <table align=\"center\" border=\"0\" width=\"500\" cellpadding=\"2\">
		<tr>
			<td colspan=\"2\" align=\"center\">Send Email to ($username)</td>
		</tr>
		<tr>
			<td width=\"100\">To:</td>
			<td><input type=\"text\" name=\"email\" size=\"27\" value=\"$email\"></td>
		</tr>
		<tr>
			<td>Subject:</td>
			<td><input type=\"text\" name=\"subject\" size=\"27\" value=\"\"></td>
		</tr>
		<tr>
			<td valign=\"top\">Message:</td>
			<td>Hello $username,<br>
                            <textarea rows=\"20\" name=\"msg\" cols=\"80\">type only your message here</textarea>
                            <br>
                            ---------------------
                            <br>
                            $site_name<br>
                            $site_url
                            
                        </td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type=\"hidden\" name=\"action\" value=\"do_SendEmail\">
                            <input type=\"submit\" value=\"Send\"></td>
		</tr>
	 </table>";
         
         include("footer.php");
}
function do_SendEmail(){
         global $email, $username, $subject, $msg, $site_name, $site_email, $site_url;

         $message = "Hello $username,\n\n";
         $message .= "$msg\n\n\n\n";
         $message .= "-----------------------\n";
         $message .= "$site_name\n";
         $message .= "$site_url\n";
         
         $to = $email;
         $header = "From: $site_name <$site_email>\n";
         $header .= "Reply-To: $site_email\n\n";

         if(mail($to, $subject, $message, $header)){

             echo "Your message has been sent.";

         }else{
               echo "<h3>"
                    ."<font color=\"#FF0000\">An error occurred while sending the email.<br>"
                    ."</font>You can try:<br>"
                    ."1- Check the email is correct.<br>"
                    ."2- Call your hosting provider to allow the function mail(); to send E-mails.<br>"
                    ."3- If your running the script on localhost (on your pc) you have to:<br>"
                    ."a: edit php.ini file. Click on (Start) menu then chose (Run) type in (php.ini) and hit Enter.<br>"
                    ."b: Look for: <br>"
                    ."------------------<br>"
                    ."[mail function]<br>"
                    ."; For Win32 only.<br>"
                    ."SMTP = localhost<br>"
                    ."-------------------<br>"
                    ."replace with:<br>"
                    ."-------------------<br>"
                    ."[mail function]<br>"
                    ."; For Win32 only.<br>"
                    ."SMTP = mail.palnet.com<br>"
                    ."SMTP_PORT = 25<br>"
                    ."-------------------<br>"
                    ."you can change mail.palnet.com to any local email provide. we just need there mail server"
                    ."<br><br>Good Luck, <br>Mohammed Ahmed";
         }

}
function SendAll(){
         include("header.php");
         global $db, $prefix, $email, $username, $site_name, $site_email, $site_url;

         nav_menu();
         
         echo "<form method=\"POST\" action=\"users.php\">
               <table align=\"center\" border=\"0\" width=\"500\" cellpadding=\"2\">
		<tr>
			<td colspan=\"2\" align=\"center\">Send Email to all Users</td>
		</tr>
		<tr>
			<td>Subject:</td>
			<td><input type=\"text\" name=\"subject\" size=\"27\" value=\"\"></td>
		</tr>
                <tr>
			<td valign=\"top\">Message:</td>
			<td>Hello Username,<br>
                            <textarea rows=\"20\" name=\"msg\" cols=\"80\">type only your message here</textarea>
                            <br>
                            ---------------------
                            <br>
                            $site_name<br>
                            $site_url

                        </td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type=\"hidden\" name=\"action\" value=\"do_SendAll\">
                            <input type=\"submit\" value=\"Send\"></td>
		</tr>
	 </table>";

         include("footer.php");
}
function do_SendAll(){
         global $db, $prefix, $subject, $msg, $site_name, $site_email, $site_url;

         $result = mysql_query("SELECT * FROM ".$prefix."_users");
         while ($row = mysql_fetch_array($result)){

               $username = $row['username'];
               $email = $row['email'];

               $message = "Hello $username,\n\n";
               $message .= "$msg\n\n\n\n";
               $message .= "-------------------------\n";
               $message .= "$site_name\n";
               $message .= "$$site_url\n";

               $to = $email;
               $header = "From: $site_name <$site_email>\n";
               $header .= "Reply-To: $site_email\n\n";

               if(mail($to, $subject, $message, $header)){
                   echo "Success sending to: $to<br>";
               }else{
                     echo "<font color=\"#FF0000\">Error:</font> Faild sending to: $to<br>";
               }//end else
         }//end while
}

switch ($action){

       case "EditUser":
            EditUser();
            break;

       case "do_EditUser":
            do_EditUser();
            break;

       case "delUser":
            delUser();
            break;

       case "SendEmail":
            SendEmail();
            break;
       case "do_SendEmail":
            do_SendEmail();
            break;

       case "SendAll":
            SendAll();
            break;

       case "do_SendAll":
            do_SendAll();
            break;
            
       Default:
               ListUsers();
               Break;
}


//////////////////////////////////
//if the admin is not logged in.
}else{
      $error_msg = "<font class=\"error\">"._ADMIN_LOGIN_ERR."</font>";
      unset($admin_name);
      unset($password);

      msg_redirect($error_msg,"index.php","1");
      exit();
}
?>
