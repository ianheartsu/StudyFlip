<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed(M@@king)    \\
Version     :  1.1                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    18-SEP-2006               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Mobile/SMS :   00972-599-622235           \\
                                          \\
===========================================\
------------------------------------------*/
include ("../functions.php");

if (is_logged_in_admin($admin)) {

function radio_validate($validate) {

    if ($validate == 0){
	$sel1 = "";
	$sel2 = "checked";
    }
    if ($validate == 1){
	$sel1 = "checked";
	$sel2 = "";
    }
    echo "<input type=\"radio\" name=\"xvalidate\" value=\"1\" $sel1>Yes "
	."<input type=\"radio\" name=\"xvalidate\" value=\"0\" $sel2>No  ";

}

function set_up(){
        global $db, $prefix;

       $sql = mysql_query("SELECT * FROM ".$prefix."_options") or die ("Error:". mysql_error());

       $row = mysql_fetch_array($sql);

          foreach( $row AS $key => $val ){
                   $$key = stripslashes( $val );
          }
  include ('header.php');

  nav_menu();
  
echo"<center> <h2>Setup site</h2>
<form method=\"POST\" action=\"options.php\">
<table align=\"center\" border=\"1\" width=\"80%\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\">
	<tr>
		<td width=\"200\">Site Name:</td>
		<td>
                    <input type=\"text\" name=\"xsite_name\" size=\"58\" value=\"$site_name\">
		</td>
	</tr>
	<tr>
		<td height=\"27\">Site Email:</td>
		<td height=\"27\"><input type=\"text\" name=\"xsite_email\" value=\"$site_email\" size=\"58\"></td>
	</tr>
	<tr>
		<td>Site URL:</td>
		<td><input type=\"text\" name=\"xsite_url\" value=\"$site_url\" size=\"58\"></td>
	</tr>
	<tr>
		<td>Site Info: </td>
		<td><textarea name=\"xsite_info\" cols=\"60\" rows=\"10\">$site_info</textarea></td>
	</tr>
	<tr>
		<td>Vaildate Email: </td>
		<td>"; radio_validate($validate); echo" (newly registered users should vaildate account via email.)</td>
	</tr>

	<tr>
		<td>Language:</td>
		<td><select name=\"xlanguage\">\n";
                    $handle=opendir("../lang/");
                    while ($file = readdir($handle)) {
                          if ( (ereg("^([_0-9a-zA-Z]+)([.]{1})([_0-9a-zA-Z]{3})$",$file))) {
                             $file = ereg_replace(".php","",$file);
                             $tlist .= "$file ";
                          }
                    }
                    closedir($handle);
                    $tlist = explode(" ", $tlist);
                    sort($tlist);
                    for ($i=0; $i < sizeof($tlist); $i++) {
	                if($tlist[$i]!="") {

	                   if ($language == $tlist[$i]) {
		              $sel = "selected";
	                   } else {
		             $sel = "";
	                   }
	                   echo "<option name=\"xlanguage\" value=\"$tlist[$i]\" $sel>$tlist[$i]</option>\n";
	                }
                    }
                    echo "</select>
                </td>
	</tr>
	<tr>
		<td colspan=2 align=center><b>Templates</td>

	</tr>
	<tr>
		<td>Header Template: </td>
		<td><textarea name=\"xtmp_header\" cols=\"120\" rows=\"10\">$tmp_header</textarea></td>
	</tr>
	<tr>
		<td>Footer Template: </td>
		<td><textarea name=\"xtmp_footer\" cols=\"120\" rows=\"10\">$tmp_footer</textarea></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td>

                        <input type=\"hidden\" name=\"maa\"  value=\"save\">
			<input type=\"submit\" value=\""._SAVECHANGES."\" name=\"B1\">
		</form>
		</td>
	</tr>
</table>
";

}


function save(){
      global  $db,$prefix,$xsite_name,$xsite_email,$xsite_url,$xsite_info,$xlanguage,$xtmp_header,$xtmp_footer,$xvalidate;



      $sql =  mysql_query("UPDATE ".$prefix."_options SET  site_name='$xsite_name',site_email='$xsite_email',site_url='$xsite_url',site_info='$xsite_info',language='$xlanguage',tmp_header='$xtmp_header',tmp_footer='$xtmp_footer',validate='$xvalidate'") or die ("Error Editing Setup: ". mysql_error());
      
      //print success message and redirect browser
      msg_redirect("Saved!","options.php","2");
          
}


switch($maa) {

         default:
             set_up();
             break;

         case "save":
             save();
             break;
}

//////////////////////////////////
//if the admin is not logged in.
}else{
      $error_msg = "<font class=\"error\">"._ADMIN_LOGIN_ERR."</font>";
      unset($admin_name);
      unset($password);

      msg_redirect($error_msg,"index.php","1");
      exit();
}

?>
