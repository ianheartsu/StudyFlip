<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed(M@@king)    \\
Version     :  1.1                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    18-SEP-2006               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Mobile/SMS :   00972-599-622235           \\
                                          \\
===========================================\
------------------------------------------*/

function nav_menu(){
         global $db, $prefix;

echo "<center>
      [ <a href=\"index.php\">Admin</a> ]
      [ <a href=\"users.php\">Users</a> ]
      [ <a href=\"options.php\">Options</a> ]
      [ <a href=\"admins.php\">Admins</a> ]
      [ <a href=\"users.php?action=SendAll\">Email All Users</a> ]
      [ <a href=index.php?maa=Logout>Logout</a> ]

      </center><br>";

}
?>
