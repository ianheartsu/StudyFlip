<?PHP


include ("functions.php");

//if the user is logged in.
if (is_logged_in($user)) {

      include ("header.php");
      //////////////////////////////////////

      //so you can put all your protected code here.
      echo "<center> you are logged in. </center>";

      /////////////////////////////// ////
      include ("footer.php");


//if the user is not logged in, then tell him to login.
}else{
     header("Location: users.php");  die();
}














?>
