<?
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed             \\
Version     :  1.2                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    26-APR-2008               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Skype      :   maaking                    \\
                                          \\
===========================================\
------------------------------------------*/

//skip the config file if somebody call it from the browser.
if (stristr($_SERVER['PHP_SELF'], "config.php")) {
    Header("Location: index.php");
    die();
}

//your databse hostname.
$db_host = "localhost";
//your database username.
$db_username = "root";
//your db user password
$db_password = "";
//your database name.
$databse_name = "login_script";
//tables prefix. Don't change unless you change this value in the db.
$prefix = "maaking";


?>
