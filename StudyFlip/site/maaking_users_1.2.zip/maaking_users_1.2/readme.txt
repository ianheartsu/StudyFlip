###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed(M@@king)    \\
Version     :  1.2                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    26-APR-2008               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Skype      :   maaking                    \\
                                          \\
===========================================\
------------------------------------------*/

#############################
Install:
#############################

- upload files to your site. e.g http://www.my-site.com/login_system/

- create a new databse and insert mysql_database.sql Using PHPMyAdmin.
- edit config file and change database info.




#############################
Upgrade: from 1.1 to 1.2
#############################

- upload and replace files to your site. e.g http://www.my-site.com/login_system/

call this file via browser: http://www.my-site.com/login_system/upgraed.php

after you finish, delete the file (upgraed.php).


#############################
Admin Page:
#############################

go to htttp://your-site.com/login_system/admin/

Username: admin
Password: maa


#############################
Changelog:
#############################

ver 1.2
- added email headers to avoid spam filters.
- added email validation option.
- fixed some secuirty issues.

ver 1.1
- moved from demo to stable.


#############################
Copyright:     GPL
#############################
the script is free to use, change and modify.
you are not allowed to remove the copyright at anytime. unless i  
give you permission.




I welcome any suggestion/modification at m@maaking.com or contact page: http://www.maaking.com/index.php?loadpage=contact


Good Luck ;)
MOhammed Ahmed
Palestine




//////////////////////////////////////////////

Note: if you got this message while testing the script on your local computer.

Warning: mail(): SMTP server response: 550 Unrouteable address in c:\appserv\www\login\admin\users.php on line 274

An error occurred while sending the email.
You can try:
1- Check the email is correct.
2- Call your hosting provider to allow the function mail(); to send E-mails.
3- If your running the script on localhost (on your pc) you have to:
a: edit php.ini file.
   Click on (Start) menu then chose (Run) type in (php.ini) and hit Enter.

b: Look for: 
------------------
[mail function]
; For Win32 only.
SMTP = localhost
-------------------
replace with:
-------------------
[mail function]
; For Win32 only.
SMTP = mail.palnet.com
SMTP_PORT = 25
-------------------
you can change mail.palnet.com to any local email provider. we just need their mail server

