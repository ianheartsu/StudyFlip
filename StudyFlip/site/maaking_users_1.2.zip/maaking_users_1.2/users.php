<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed             \\
Version     :  1.2                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    26-APR-2008               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Skype      :   maaking                    \\
                                          \\
===========================================\
------------------------------------------*/
include ("functions.php");

// the Default function.
//note for functions: if you want to include a value of some variables inside the funtions,
//then you have to GLOBAL it first.
function index($user) {
     global $db, $prefix;

     //check if the user is logged in or not.
     if (is_logged_in($user)) {
          include("header.php");

          //get_my_info($user);
          $cookie_read = explode("|", base64_decode($user));
          //define variables to hold cookie values.
          $userid = $cookie_read[0];
          $username = $cookie_read[1];
          $password = $cookie_read[2];
          $ipaddress = $cookie_read[3];
          $lastlogin_date = $cookie_read[4];
          $lastlogin_time = $cookie_read[5];
          if($ipaddress == "") $ipaddress = ""._NOT_YET."";
          
          //print wilcome message
          echo ""._WELCOME." <b>$username</b>, "._LAST_LOGIN." "._FROM.": [$ipaddress] "._ON." [$lastlogin_date @ $lastlogin_time] (<a href=users.php?maa=Logout>"._LOGOUT."</a>)";
          echo "<br><br><br><br>";
          navigation_menu();
          
          include("footer.php");
     }else{
         //if the user is not logged in then show the login form.
         //  header("Location: users.php?maa=Login");  die();
         include("header.php");
         login_form();
         include("footer.php");
    }
}
################################################################################
#------------------------------------------------------------------------------#
#  navigation menu
#------------------------------------------------------------------------------#
################################################################################
function navigation_menu(){
echo  " <center>"
     ." [ <a href=\"index.php\">"._HOME."</a> ] "
     ." [ <a href=\"users.php\">"._MY_ACCOUNT."</a> ] "
     ." [ <a href=\"users.php?maa=EditMyInfo\">"._CHANGE_MY_INFO."</a> ]"
     ." [ <a href=\"users.php?maa=ChangePWD\">"._CHANGE_MY_PASSWORD."</a> ]"
     ." [ <a href=\"users.php?maa=Logout\">"._LOGOUT."</a> ]"
     ." </center><br>";
}
################################################################################
#------------------------------------------------------------------------------#
#  login
#------------------------------------------------------------------------------#
################################################################################
//the login form
// in this form there is hidden field (<input type=\"hidden\" name=\"maa\" value=\"do_login\">)
//this used to do the login process
function login_form(){
         global $username,$user_err,$pass_err,$error_msg;

echo "<center><font class=\"title\">"._PLEASE_ENTER_YOUR_USER."</font></center>\n";
echo "
<center>
      <form method=\"POST\" action=\"users.php\" name=\"loginform\">
        <table border=\"0\" cellspacing=\"2\" cellpadding=\"4\">
        <tr>
            <td bgcolor=\"#E2E2E2\">"._USERNAME." : </td>
            <td bgcolor=\"#E2E2E2\"><input type=\"text\" name=\"username\" value=\"$username\" size=\"11\"> $user_err</td>
        </tr>
        <tr>
            <td bgcolor=\"#E2E2E2\">"._PASSWORD." : </td>
            <td bgcolor=\"#E2E2E2\"><input type=\"password\" name=\"password\" size=\"11\"> $pass_err</td>
        </tr>
        <tr>
             <td colspan=2>"._REMEBER_ME." <input type=\"checkbox\" name=\"remember\" value=\"ON\"></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td> <input type=\"hidden\" name=\"maa\" value=\"do_login\">
                 <input type=\"submit\" value=\""._LOGIN."\"></p>
            </td>
        </tr>
        </table> $error_msg
      </form>[<a href=\"index.php\">"._HOME."</a>] [ <a href=\"users.php?maa=Register\">"._REGISTER."</a> <img src=\"images/register.gif\"> ] [ <a href=\"users.php?maa=Forgot_pwd\">"._FORGOT_PASSWORD."</a> <img src=\"images/forgot_pwd.gif\"> ]<br><br>";
}

//a login function to call the login form.
function Login(){
        include("header.php");
        login_form();
        include("footer.php");
}

//this function will do the login porcess for you.
function do_login(){
// define the values from the form.
//note for functions: if you want to include a value of some variables inside the funtions,
//then you have to GLOBAL it first.
         global $prefix,$db,$username,$password, $remember, $user_err,$pass_err,$error_msg,$validate;

         //check username and password fields.
         if((!$username) || (!$password)){
                include("header.php");

                $reqmsg= "(<font class=\"error\">"._REQUIRED."</font>)";
                if(trim(empty($username))){
                   $user_err= $reqmsg;
                }
                if(empty($password)){
                   $pass_err= $reqmsg;
                }

                //load the login form again.
                login_form();
                include("footer.php");
                exit();
         }

         ##--nothing empty? lets do the login
         //encyrpt  password for more Security
         $md5_pass = md5($password);
         $sql = $db->sql_query("SELECT * FROM ".$prefix."_users WHERE username='$username' AND password='$md5_pass'");
         $login_check = $db->sql_numrows($sql);
         ///////////////////////////////////////////////////////////////////////
         //if the entered informations are correct, then login and create the cookies.
         if($login_check > 0){
                 $row = $db->sql_fetchrow($sql);

                 $userid = $row['userid'];
                 $username = $row['username'];
                 $password = $row['password'];
                 $ipaddress = $row['ipaddress'];
                 $isactive = $row['isactive'];
                 
                 #if the user hasn't validated his account.
                 if($isactive == 0){
                    include("header.php");
                    echo "<br><br><br>";
                    echo "<font class=error>"._VALIDATE_ERROR_LOGIN."</font> ";
                    echo "<br><br>"._GOHOME."<br>";
                    include("footer.php");
                    exit();
                 
                 }

                 $lastlogin = explode(" ", $row['lastlogin']);
                 $lastlogin_date =  $lastlogin[0];
                 $lastlogin_time = $lastlogin[1];

                 $info = base64_encode("$userid|$username|$password|$ipaddress|$lastlogin_date|$lastlogin_time");
                 if (isset($remember)){
                     setcookie("user","$info",time()+1209600);
                 }else{
                     setcookie("user","$info",0);
                 }
                 $db->sql_query("UPDATE ".$prefix."_users SET ipaddress='$REMOTE_ADDR', lastlogin=NOW() WHERE userid='$userid'");

                 //print success message and redirect browser
                 msg_redirect(""._LOGIN_SUCCESS."","users.php","5");

         //if the entered informations are wrong, then print error message.
         }else{
                //include("header.php");
                $error_msg = "<font class=\"error\">"._LOGIN_ERROR."</font>";
                unset($username);
                unset($password);

                include("header.php");
                login_form();
                include("footer.php");
                exit();
         }
}


################################################################################
#------------------------------------------------------------------------------#
#  logout
#------------------------------------------------------------------------------#
################################################################################
function Logout($user) {
         global $db, $prefix;
         
         unset($user);
         setcookie("user", false);
         $user = "";
         header("Location: users.php");
    
}
################################################################################
#------------------------------------------------------------------------------#
#  Register
#------------------------------------------------------------------------------#
################################################################################
function Register(){

         include("header.php");
         register_form();
         include("footer.php");
}

function register_form(){
         global $username, $password, $password2, $email, $fullname, $user_taken_err, $email_taken_err;
echo "<center><font class=\"title\">"._REG_FORM."</font></center><br>\n";
//onsubmit='return CheckRegisterForm(RegisterForm)'
echo "<center>"._FILED_STAR_REQUIRED."
      <form name=\"RegisterForm\" method=\"POST\" action=\"users.php\">
      <table align=\"center\" border=\"1\" width=\"400\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\">
		<tr>
			<td width=\"150\" align=\"right\">"._USERNAME." :</td>
			<td><input type=\"text\" name=\"username\" size=\"18\" value=\"$username\"> * $user_taken_err</td>
		</tr>
		<tr>
			<td align=\"right\">"._PASSWORD." :</td>
			<td><input type=\"password\" name=\"password\" size=\"18\" value=\"$password\"> *</td>
		</tr>
		<tr>
			<td align=\"right\">"._RETYPE_PASSWORD." :</td>
			<td><input type=\"password\" name=\"password2\" size=\"18\" value=\"$password2\"> *</td>
		</tr>
		<tr>
			<td align=\"right\">"._EMAIL." :</td>
			<td><input type=\"text\" name=\"email\" size=\"27\" value=\"$email\"> * $email_taken_err</td>
		</tr>
		<tr>
			<td align=\"right\">"._FULLNAME." :</td>
			<td><input type=\"text\" name=\"fullname\" size=\"27\" value=\"$fullname\"></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td> <input type=\"hidden\" name=\"maa\" value=\"do_Register\">
                             <input type=\"submit\" value=\""._REGISTER."\"></td>
		</tr>
	</table>
	</form>
        <center>"._GOBACK." "._GOHOME."</center>";
}
function do_Register(){
          global $db, $prefix, $username, $password, $password2, $email, $fullname, $user_taken_err, $email_taken_err;
          global $site_name, $site_email, $site_url, $validate;
          
          //this function will check fields incase of javascript not working.
          if((!$username) || (!$password) || (!$password2) || (!$email)){

                if(trim(empty($username))){

                }
                if(empty($password)){

                }
                if(empty($password2)){

                }
                if(trim(empty($email))){

                }
                //print the error message and load the form.
                include("header.php");


                echo "<center><font class=\"error\">"._ERROR_PLEASE_FILL_FIELDS."</font></center>\n";
                register_form();
                include("footer.php");
                exit();
          }
          //this code will check if the 2 passwords are match or not.
          if($password != $password2){
                //print the error message and load the form.
                include("header.php");

                register_form();
                echo "<center><font class=\"error\">"._ERROR_PASSWORD_DOESNT_MATCH."</font></center>\n";

                include("footer.php");
                exit();
          }
          //this code will check if the email is correct or not
          if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)){
                //print the error message and load the form.
                include("header.php");

                register_form();
                echo "<center><font class=\"error\">"._ERROR_INVALID_EMAIL."</font></center>\n";

                include("footer.php");
                exit();
          }
          
          
          //--nothing empty? everything is okay? lets do the register.
          $sql_email_check = $db->sql_query("SELECT email FROM ".$prefix."_users WHERE email='$email'");
          $sql_username_check = $db->sql_query("SELECT username FROM ".$prefix."_users WHERE username='$username'");
          $email_check = $db->sql_numrows($sql_email_check);
          $username_check = $db->sql_numrows($sql_username_check);

          if(($email_check > 0) || ($username_check > 0)){

               //define error message for usage in multi plces.
               $exist_msg= "<font class=\"error\">"._ALREADY_TAKEN."</font>";

               if($email_check > 0){
                  $email_taken_err =  $exist_msg;
                  unset($email);
               }

               if($username_check > 0){
                  $user_taken_err =  $exist_msg;
                  unset($username);
               }

               //if the username or email already been taken load the form and print errors.
               include("header.php");
               register_form();
               include("footer.php");
               exit();
          }
          
          //if you as and admin forsed users to vaildate their accounts.
          if($validate == 1){
             $isactive = 0;
             //generate random code
             $code = md5(time());
             $code = rand(0,999999999);
             
             $subject = _VALIDATE_EMAIL;

          }else{
                $isactive = 1;
                $subject = _YOUR_INFO_AT;
          }
          
          $md5_password = md5($password);
          $result = $db->sql_query("INSERT INTO ".$prefix."_users ( username,password,email,fullname,regdate,isactive,code) "
                                                       ."  VALUES('$username','$md5_password','$email','$fullname',NOW(),'$isactive','$code')");
          $eol ="\r\n";
          $message = "$eol";
          $message .= ""._WELCOME_TO." $site_name $eol";
          $message .= "$eol";
          $message .= ""._PLZ_KEEP_THIS_EMAIL." $eol";
          $message .= "$eol";
          $message .= "---------------------------- $eol";
          $message .= ""._USERNAME.": $username  $eol" ;
          $message .= ""._PASSWORD.": $password $eol";
          $message .= "---------------------------- $eol";
          $message .= "$eol" ;

          if($validate == 1){
          $message .= ""._YOUR_ACCOUNT_IS_NOT_ACTIVE." $eol";
          $message .= "$eol" ;
          $message .= "$site_url/users.php?maa=Activate&code=$code $eol";
          }else{
          $message .= ""._YOUR_ACCOUNT_IS_CURRENTLY_ACTIVE." $eol";
          $message .= "$eol" ;
          $message .= "$site_url $eol";
          }

          $message .= "$eol";
          $message .= ""._PLZ_DONT_FORGOT_PWD." $eol";
          $message .= " $eol";
          $message .= ""._THANKS_FOR_REGISTERING."  $eol";
          $message .= "$eol";
          $message .= "-- $eol";
          $message .= "- $site_name $eol";
          $message .= "$site_url $eol";
          $message .= "$eol";
          $message .= "$eol";
          $message .= ""._THIS_EMAIL_AUTO_GENERATED." $eol" ;
          $message .= ""._DONT_RESPOND_WILL_IGNORED." $eol";

          #set email headers  to aviod spam filters
          $headers .= "From: ".$site_name."<".$site_email.">".$eol;
          $headers .= "Reply-To: ".$site_name."<".$site_email.">".$eol;
          $headers .= "Return-Path: ".$site_name."<".$site_email.">".$eol;
          $headers .= "Message-ID: <".time()."-".$site_email.">".$eol;
          $headers .= "X-Mailer: PHP v".phpversion().$eol;
          $headers .= 'MIME-Version: 1.0'.$eol.$eol;
          
          if(!mail($email,$subject,$message, $headers)){
             die (""._EMAIL_DIE."");
          }else{
                include("header.php");

                   if($validate == 1){
                      echo "<br><br><div align=\"center\" class=\"div\">"._REG_SUCCESS_VALIDATE."</div><br><br> <center>"._GOHOME."</center>";

                   }else{
                         echo "<div align=\"center\" class=\"div\">"._REG_SUCCESS."</div>";
                         login_form();
                   }


                
                include("footer.php");
         }
}

################################################################################
#------------------------------------------------------------------------------#
#  Forgot Password
#------------------------------------------------------------------------------#
################################################################################
function Forgot_pwd_form(){
global $error_msg;

echo "<center><font class=\"title\">"._SEND_NEW_PASSWORD."</font>
<form method='POST' action='users.php'>
<table border='0' cellpadding='4'>
        <tr>
                <td bgcolor='#E2E2E2'>"._USERNAME." :</td>
                <td bgcolor='#E2E2E2'><input type='text' name='username' size='11'></td>
        </tr>
        <tr>
                <td bgcolor='#E2E2E2'>"._EMAIL." :</td>
                <td bgcolor='#E2E2E2'><input type='text' name='email' size='11'></td>
        </tr>
        <tr>
                <td>&nbsp;</td>
                    <td>
                    <input type='hidden' name='maa' value='do_Forgot_pwd'>
                    <input type='submit' value='"._SEND_PASSWORD."'></p>
                </td>
        </tr>
</table><center>$error_msg</center>
</form>";
}

function Forgot_pwd(){
         global $user, $prefix, $db;

         include("header.php");
         Forgot_pwd_form();
         include("footer.php");
}

function do_Forgot_pwd(){
         global $user, $prefix, $db, $email, $username, $error_msg, $site_name ,$site_email, $site_url;

         $result = $db->sql_query("SELECT * FROM ".$prefix."_users WHERE username='$username' AND email='$email'");
         $check = $db->sql_numrows($result);
         if($check == 1){

         function new_pwd() {
                  $chars = "abchefghjkmnpqrstuvwxyz0123456789";
                  srand((double)microtime()*1000000);
                  $i = 0;
                  while ($i <= 7) {
                            $num = rand() % 33;
                            $tmp = substr($chars, $num, 1);
                            $pwd = $pwd . $tmp;
                            $i++;
                  }
                  return $pwd;
         }
         $new_pwd = new_pwd();
         $md5_password = md5($new_pwd);
         $sql = $db->sql_query("UPDATE ".$prefix."_users SET password='$md5_password' WHERE email='$email'");

         $eol ="\r\n";
         
         $subject = ""._NEW_PASSWORD."";
         $message = "$eol";
         $message .= ""._HELLO." $username, $eol";
         $message .= " $eol";
         $message .= ""._YOU_ARE_RECEIVING_EMAIL." $site_name. $eol";
         $message .= "  $eol";
         $message .= ""._HERE_ISIT_BELOW." $eol";
         $message .= "--------------------------$eol";
         $message .= ""._USERNAME.": $username  $eol";
         $message .= ""._PASSWORD.": $new_pwd  $eol";
         $message .= "--------------------------  $eol";
         $message .= ""._YOU_MAY_LOGIN_BELOW."  $eol";
         $message .= "$site_url  $eol";
         $message .= "  $eol";
         $message .= ""._YOU_CAN_OFCOURSE_CHANGE_PWS." $eol";
         $message .= "  $eol";
         $message .= "-- $eol";
         $message .= "-"._THANKS."  $eol";
         $message .= "$site_name $eol";
         $message .= "   $eol";
         $message .= ""._THIS_EMAIL_AUTO_GENERATED." $eol";
         $message .= ""._DONT_RESPOND_WILL_IGNORED." $eol";


          #set email headers  to aviod spam filters
          $headers .= "From: ".$site_name."<".$site_email.">".$eol;
          $headers .= "Reply-To: ".$site_name."<".$site_email.">".$eol;
          $headers .= "Return-Path: ".$site_name."<".$site_email.">".$eol;
          $headers .= "Message-ID: <".time()."-".$site_email.">".$eol;
          $headers .= "X-Mailer: PHP v".phpversion().$eol;
          $headers .= 'MIME-Version: 1.0'.$eol.$eol;

         if(!mail($email,$subject,$message, $headers)){
             die (""._EMAIL_DIE."");
         }

         //print success message and redirect browser
         msg_redirect(""._NEW_PWD_SENT_TO_YOUR_EMAIL."","users.php","10");

         //this else for :  if($check == 1){
         }else{
                include("header.php");
                Forgot_pwd_form();
                echo "<center><font class=\"error\">"._WRONG_USEREMAIL."</font></center><br>";
                include("footer.php");
         }
}

################################################################################
#------------------------------------------------------------------------------#
#  Change Password
#------------------------------------------------------------------------------#
################################################################################
function change_pwd_form(){
         global $user;
  if (is_logged_in($user)) {
   navigation_menu();
   
   echo "<center><font class=\"title\">"._CHANGE_MY_PWD."</font>
         <br> "._ONCE_CHANGED_LOGOUT."
         <form method='POST' action='users.php'>
         <table border='0' cellpadding='4'>
         <tr>
                <td bgcolor='#E2E2E2'>"._OLD_PWD." :</td>
                <td bgcolor='#E2E2E2'><input type='password' name='old_pwd' size='11'></td>
         </tr>
         <tr>
                <td bgcolor='#E2E2E2'>"._NEW_PWD." :</td>
                <td bgcolor='#E2E2E2'><input type='password' name='new_pwd1' size='11'></td>
         </tr>
         <tr>
                <td bgcolor='#E2E2E2'>"._CONFIRM_NEW_PWD." :</td>
                <td bgcolor='#E2E2E2'><input type='password' name='new_pwd2' size='11'></td>
         </tr>
         <tr>
                <td align=center colspan=2>
                    <input type='hidden' name='maa' value='do_ChangePWD'>
                    <input type='submit' value='"._CHANGE_PWD."'></p>
                </td>
         </tr>
         </table>
         </form>";
  }else{
        echo "<br /><center><font class=\"title\">"._NOT_AUTHORIZED."</font>";
  }
}
function ChangePWD(){
         global $user, $prefix, $db;

         include("header.php");
         change_pwd_form();
         include("footer.php");
}
function do_ChangePWD(){
         global $user, $prefix, $db, $old_pwd, $new_pwd1, $new_pwd2;

  if (is_logged_in($user)) {

         //check empty fields
         if((empty($old_pwd)) or (empty($new_pwd1)) or (empty($new_pwd2))){
            include("header.php");
            change_pwd_form();
            echo "<center><font class=\"error\">"._ERROR_PLEASE_FILL_FIELDS."</font>";
            include("footer.php");
            exit();
         }
         
         $cookie_read = explode("|", base64_decode($user));
         $userid = $cookie_read[0];
         
         $old_pwd_md5 = md5($old_pwd);
         $result = $db->sql_query("SELECT userid,password FROM ".$prefix."_users WHERE userid='$userid' AND password='$old_pwd_md5'");

         if($db->sql_numrows($result) == 0){
         
               include("header.php");
               change_pwd_form();
               echo "<center><font class=\"error\">"._OLD_PWD_DONT_MATCH."</font></center><br>";
               include("footer.php");
               exit();
               
         }else{

               if($new_pwd1 != $new_pwd2){

                     include("header.php");
                     change_pwd_form();
                     echo "<center><font class=\"error\">"._ERROR_NEW_PWD_DOESNT_MATCH."</font></center><br>";
                     include("footer.php");
                     exit();
                     
               }else{

                     $md5_password = md5($new_pwd1);
                     $sql = $db->sql_query("UPDATE ".$prefix."_users SET password='$md5_password' WHERE userid='$userid'");

                     $msg = ""._SUCCESS_PWD_CHANGED." <br> "._PLZ_REMEBER_NEW_PWS." ";
                     //print success message and redirect browser
                     msg_redirect("$msg","users.php","10");
               }
         }
  }else{
        echo "<br /><center><font class=\"title\">"._NOT_AUTHORIZED."</font>";
  }

}
################################################################################
#------------------------------------------------------------------------------#
#  Change MyInfo
#------------------------------------------------------------------------------#
################################################################################
function EditMyInfo(){

         include("header.php");
         EditMyInfo_form();
         include("footer.php");
}

function EditMyInfo_form(){
         global $user, $db, $prefix, $username, $password, $email, $fullname, $user_taken_err, $email_taken_err;

  if (is_logged_in($user)) {
         navigation_menu();
         
         $cookie_read = explode("|", base64_decode($user));
         $userid = $cookie_read[0];
         $result = $db->sql_query("SELECT * FROM ".$prefix."_users WHERE userid='$userid'");
         $row = $db->sql_fetchrow($result);
         
         echo "<center><font class=\"title\">"._CHANGE_MY_INFORMATION."</font></center><br>\n";
         echo "<center>"._FILED_STAR_REQUIRED."
               <form name=\"EditMyInfoForm\" method=\"POST\" action=\"users.php\">
               <table align=\"center\" border=\"1\" width=\"500\" id=\"table1\" cellpadding=\"2\" bordercolor=\"#C0C0C0\">
		<tr>
			<td  width=\"100\" align=\"right\">"._USERNAME." :</td>
			<td><input type=\"text\" disabled=\"true\" name=\"username\" size=\"18\" value=\"$row[username]\"></td>
		</tr>
		<tr>
			<td align=\"right\">"._EMAIL." :</td>
			<td><input type=\"text\" name=\"email\" size=\"27\" value=\"$row[email]\">  * $email_taken_err</td>
		</tr>
		<tr>
			<td align=\"right\">"._FULLNAME." :</td>
			<td><input type=\"text\" name=\"fullname\" size=\"27\" value=\"$row[fullname]\"></td>
		</tr>
		<tr>
			<td align=\"right\">"._WEBSITE." :</td>
			<td><input type=\"text\" name=\"site\" size=\"27\" value=\"$row[site]\"> "._EG." http://www.site.com</td>
		</tr>
                <tr>
			<td align=\"right\">"._COUNTRY." :</td>
			<td><input type=\"text\" name=\"country\" size=\"27\" value=\"$row[country]\"></td>
		</tr>
		<tr>
			<td align=\"right\">"._CITY.":</td>
			<td><input type=\"text\" name=\"city\" size=\"27\" value=\"$row[city]\"></td>
		</tr>
		<tr>
			<td align=\"right\">"._TEL_MOBILE." :</td>
			<td><input type=\"text\" name=\"tel\" size=\"27\" value=\"$row[tel]\"></td>
		</tr>
		<tr>
			<td align=\"right\">"._PROFILE.":</td>
			<td><textarea rows=\"5\" name=\"profile\" cols=\"30\">$row[profile]</textarea></td>
		</tr>
                <tr>
			<td>&nbsp;</td>
			<td> <input type=\"hidden\" name=\"maa\" value=\"do_EditMyInfo\">
                             <input type=\"submit\" value=\""._SAVE_CHANGES."\"></td>
		</tr>
	       </table></form>";

  }else{
        echo "<br /><center><font class=\"title\">"._NOT_AUTHORIZED."</font>";
  }
  
}
function do_EditMyInfo(){
          global $user, $db, $prefix, $email, $fullname, $email_taken_err;
          global $site, $country, $city, $tel, $profile;
          global $site_name, $site_email, $site_url;

  if (is_logged_in($user)) {
          //this function will check fields incase of javascript not working.
          if(trim(empty($email))){
             //print the error message and load the form.
             include("header.php");

             EditMyInfo_form();
             echo "<center><font class=\"error\">"._ERROR_PLEASE_FILL_FIELDS."</font></center>\n";
             include("footer.php");
             exit();
          }

          $cookie_read = explode("|", base64_decode($user));
          $userid = $cookie_read[0];
         
          /*--nothing empty? everything is okay? lets do the changes--*/
          $sql_email_check = $db->sql_query("SELECT email FROM ".$prefix."_users WHERE email='$email' AND userid!='$userid'");
          $email_check = $db->sql_numrows($sql_email_check);
          //define error message for usage in multi plces.
          $exist_msg= "<font class=\"error\">("._THE_EMAIL." $email: "._ALREADY_TAKEN.")</font>";

          if($email_check > 0){
                  $email_taken_err =  $exist_msg;
                  unset($email);
                  //if the email already been taken load the form and print errors.
                  include("header.php");
                  EditMyInfo_form();
                  include("footer.php");
                  exit();
          }

          $result = $db->sql_query("UPDATE ".$prefix."_users
                                        SET email='$email',
                                        fullname='$fullname',
                                        site='$site',
                                        country='$country',
                                        city='$city',
                                        tel='$tel',
                                        profile='$profile'
                                        WHERE userid='$userid'");

          //print success message and redirect browser
          msg_redirect(""._YOUR_INFO_HAS_BEEN_CHANGES."","users.php","5");
  }else{
        echo "<br /><center><font class=\"title\">"._NOT_AUTHORIZED."</font>";
  }
  
  
}

################################################################################
#------------------------------------------------------------------------------#
#  Activate Function
#------------------------------------------------------------------------------#
################################################################################
function Activate(){
         global $user, $db, $prefix, $code;

         $code = intval($code);

         if(isset($code) != 0){
         
             $result = $db->sql_query("SELECT userid FROM ".$prefix."_users WHERE code='$code'");

             if($db->sql_numrows($result) == 1){

                   $row = $db->sql_fetchrow($result);

                   $sql = $db->sql_query("UPDATE ".$prefix."_users SET isactive='1',code='0' WHERE userid='$row[userid]'");
         
                   msg_redirect(""._VALIDATE_DONE."","users.php","10");
                
             }else{
                   echo _VALIDATE_ERROR;
             }
         
         }
}


################################################################################
#------------------------------------------------------------------------------#
#  a switch  for switching between functions
#------------------------------------------------------------------------------#
################################################################################
switch ($maa){

       case "EditMyInfo":
            EditMyInfo();
            break;

       case "do_EditMyInfo":
            do_EditMyInfo();
            break;
            
       case "ChangePWD":
            ChangePWD();
            break;

       case "do_ChangePWD":
            do_ChangePWD();
            break;
            
       case "Forgot_pwd":
            Forgot_pwd();
            break;

       case "do_Forgot_pwd":
            do_Forgot_pwd();
            break;
            
       case "Register":
            Register();
            break;

       case "do_Register":
            do_Register();
            break;
            
       case "Logout":
            Logout($user);
            break;
            
       case "Login":
            Login();
            break;

       case "do_login":
            do_login();
            break;

       case "Activate":
            Activate();
            break;
            
       //load the default function.
       Default:
               index($user);
               Break;
}
//update No. 0.0.2
//last update DEC 03, 2005 @ 9:30 PM Gaza time. (+2 GMT)
?>
