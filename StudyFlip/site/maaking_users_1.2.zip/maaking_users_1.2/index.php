<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed             \\
Version     :  1.2                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    26-APR-2008               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Skype      :   maaking                    \\
                                          \\
===========================================\
------------------------------------------*/

include ("functions.php");

//if the user is logged in.
if (is_logged_in($user)) {

     include ("header.php");
      $cookie_read = explode("|", base64_decode($user));
      $username = $cookie_read[1];
      //put your code here (protected page).
      echo "Welcome <b>$username</b>, [ <a href=users.php>Manage Account</a> ] [ <a href=users.php?maa=Logout>Logout</a> ]<br><br>";



             echo "<br><br><br>
             <h3>an example of protected page, put your protected code/stuff here.</h3>";





      include ("footer.php");



//if the user is not logged in, then tell him to login.
}else{

      include ("header.php");
     //header("Location: users.php");  die();
     echo "Welcome visitor, would you like to [ <a href=users.php>Login</a> ] or [ <a href=\"users.php?maa=Register\">Register</a> ]";


     //this code will load all registered users
         $sql = mysql_query("SELECT * FROM ".$prefix."_users ORDER BY userid DESC");
         $num = mysql_num_rows($sql);
            echo "<br><br><br><hr size=1>Total registered users ($num): ";
            while($row = mysql_fetch_array($sql)){
                 $userid = $row['userid'];
                 $username = $row['username'];
                 $password = $row['password'];
                 $ipaddress = $row['ipaddress'];
              #comment this line if you don't want to print user names.
              echo " [ $username ]";
          }
     include ("footer.php");

}














?>
