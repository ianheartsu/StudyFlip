-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 26, 2008 at 06:17 AM
-- Server version: 5.0.37
-- PHP Version: 5.2.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `login_script`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `maaking_admin`
-- 

CREATE TABLE `maaking_admin` (
  `adminid` int(11) NOT NULL auto_increment,
  `admin_name` varchar(10) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `fullname` varchar(50) default NULL,
  `site` varchar(105) NOT NULL default '',
  `country` varchar(50) NOT NULL default '',
  `city` varchar(50) NOT NULL default '',
  `tel` varchar(50) NOT NULL default '',
  `profile` text NOT NULL,
  `regdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `ipaddress` varchar(50) NOT NULL default '',
  `lastlogin` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`adminid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `maaking_admin`
-- 

INSERT INTO `maaking_admin` (`adminid`, `admin_name`, `password`, `email`, `fullname`, `site`, `country`, `city`, `tel`, `profile`, `regdate`, `ipaddress`, `lastlogin`) VALUES 
(1, 'admin', '71a81e2afb8ac1659c61c04c9d638f68', 'm@maaking.com', 'Mohammed Ahmed', '', '', '', '', '', '0000-00-00 00:00:00', '', '2008-04-26 04:54:24');

-- --------------------------------------------------------

-- 
-- Table structure for table `maaking_options`
-- 

CREATE TABLE `maaking_options` (
  `site_name` varchar(50) NOT NULL default '',
  `site_email` varchar(50) NOT NULL default '',
  `site_url` varchar(50) NOT NULL default '',
  `site_info` text NOT NULL,
  `language` varchar(50) default NULL,
  `tmp_header` text NOT NULL,
  `tmp_footer` text NOT NULL,
  `validate` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `maaking_options`
-- 

INSERT INTO `maaking_options` (`site_name`, `site_email`, `site_url`, `site_info`, `language`, `tmp_header`, `tmp_footer`, `validate`) VALUES 
('maaking Login System', 'm@maaking.com', 'http://www.maaking.com/', 'login script, login, php, maaking,,,,,', 'english', '<div align="center">\r\n	<table border="1" width="750" id="table1" cellpadding="2" bordercolor="#C0C0C0" height="74">\r\n		<tr>\r\n			<td bgcolor="#F2FAFF">go to setup and put all your \r\n			stuff header here.</td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n\r\n\r\n<!-- table for main suff-->\r\n	<div align="center">\r\n	<table border="0" width="750" id="table2" cellspacing="4" cellpadding="4">\r\n		<tr>\r\n			<td>', '</td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<!-- end of table for main suff-->\r\n\r\n\r\n<div align="center">\r\n	<table border="1" width="750" id="table1" cellpadding="2" bordercolor="#C0C0C0" height="50">\r\n		<tr>\r\n			<td bgcolor="#F2FAFF">go to setup and put all your \r\n			stuff footer here.</td>\r\n		</tr>\r\n	</table>\r\n</div>', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `maaking_users`
-- 

CREATE TABLE `maaking_users` (
  `userid` int(11) NOT NULL auto_increment,
  `username` varchar(10) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `fullname` varchar(50) default NULL,
  `site` varchar(105) NOT NULL default '',
  `country` varchar(50) NOT NULL default '',
  `city` varchar(50) NOT NULL default '',
  `tel` varchar(50) NOT NULL default '',
  `profile` text NOT NULL,
  `regdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `ipaddress` varchar(50) NOT NULL default '',
  `lastlogin` datetime NOT NULL default '0000-00-00 00:00:00',
  `isactive` tinyint(1) NOT NULL default '0',
  `code` varchar(10) NOT NULL,
  PRIMARY KEY  (`userid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `maaking_users`
-- 

