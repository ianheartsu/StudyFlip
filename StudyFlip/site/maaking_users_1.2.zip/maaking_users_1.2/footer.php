<?PHP
###########################################
#-----------Users login system------------#
###########################################
/*=========================================\
Author      :  Mohammed Ahmed             \\
Version     :  1.2                        \\
Date Created:  Aug 20  2005               \\
----------------------------              \\
Last Update:    26-APR-2008               \\
----------------------------              \\
Country    :   Palestine                  \\
City       :   Gaza                       \\
E-mail     :   m@maaking.com              \\
WWW        :   http://www.maaking.com     \\
Skype      :   maaking                    \\
                                          \\
===========================================\
------------------------------------------*/

if (eregi("footer.php", $_SERVER['SCRIPT_NAME'])) {
    Header("Location: index.php"); die();
}

global $tmp_footer;
//print the footer template
echo "$tmp_footer";

#Please - Please - Please - Please -Please - Please -Please #
//please don't remove my Copy Right untill i permit you
//just email me about that
//thanks
echo "<hr size=1 align=center width=750><center>Script by: <a href=\"http://www.maaking.com\" target=\"_blank\">maaking.com</a></center>";

?>
