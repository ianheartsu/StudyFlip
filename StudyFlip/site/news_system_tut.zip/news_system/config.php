<?php

//LAST UPDATE
// 27-09-2007

// Set Mysql Variables
//Change the following


$dbhost="localhost";  #SQL Database Hostname (Most is: localhost)
$dbusername="user";   #SQL Username
$dbpassword="pass";   #SQL Password
$dbname="news_sysem"; #SQL Database Name

#for support please email me: m@maaking.com


// Don't touch here anything.
// Connect to Mysql
$connect = mysql_connect($dbhost, $dbusername, $dbpassword);
//Select the correct database.
$db = mysql_select_db($dbname,$connect) or die ("Could not select database");
?> 


