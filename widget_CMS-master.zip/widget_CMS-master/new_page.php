<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php require_once("includes/form_functions.php");?>
<?php
	if(intval($_GET['subj'])==0)
	{
		redirect_to("content.php");
	}
	
	if(isset($_POST['submit']))
	{
		//Validate the form data to see if there were any errors 
		$errors=array();
		$required_fields=array('menu_name','position','content');
    $errors=array_merge($errors,check_required_fields($required_fields));
		// foreach($required_fields as $fieldname)
		// {
		// 	if(!isset($_POST[$fieldname]) || empty($_POST[$fieldname]))
		// 	{
		// 		$errors[]=$fieldname;
		// 	}
		// }

		$fields_with_lengths=array('menu_name'=>30);
    $errors=array_merge($errors,check_max_field_lengths($fields_with_lengths));
		// foreach($fields_with_lengths as $fieldname=>$maxlength)
		// {
		// 	if(strlen(trim(mysql_prep($_POST[$fieldname])))>$maxlength)
		// 	{
		// 		$errors[]=$fieldname;
		// 	}
		// }



        if(empty($errors))
        {
                $subject_id=mysql_prep($_GET['subj']);
                $menu_name=trim(mysql_prep($_POST['menu_name']));
                $position=mysql_prep($_POST['position']);
                $visible=mysql_prep($_POST['visible']);
                $content=mysql_prep($_POST['content']);
                $errors[]="stack";

                $query="INSERT INTO pages
                (subject_id,menu_name,position,visible,content)
                VALUES 
                ({$subject_id},'{$menu_name}',{$position},{$visible},'{$content}')";


                if(mysql_query($query,$connection))
                {
                	//Success
                	$id=mysql_insert_id();
                	redirect_to("content.php?page={$id}");
                	exit;
                }
                else 
                {
                	//Failure
                	$message="The page could not be created.";
                  $message.="<br/>".mysql_error();
                }
        } else 
        {
            if(count($errors)==1){
              $message="There was 1 error in the form.";
            } else {
              $message="There where ".count($errors)." errors in the form";
            }	
        }
		//INSERT data with mysql
	}
?>
<?php 

	find_selected_page(); //and subject

?>
<?php include("includes/header.php"); ?> 
	<table id="structure">
		<tr>
			<td id="navigation">
				<?php	echo navigation($sel_subject,$sel_page);?>
			</td>
			<td id="page">
                  <h2>Adding new page</h2>
                  <?php 
                        if(!empty($message)){
                          echo "<p class=\"message\">{$message}</p>";
                        }
                   ?>  
                   <?php
                        if(!empty($errors))
                        {
                            display_errors($errors);
                        }
                   ?>   
                  <form action="new_page.php?subj=<?php 
                  echo rawurlencode($sel_subject['id']);?>"  method="post">
 						<o>Page name: 
 							<input type="text" name="menu_name" value="" id="menu_name"/>
 						</p>
 						<p>Position:
 							<select name="position">
 								<?php
 									$page_set=get_pages_for_subject($sel_subject['id']);
 									$page_count=mysql_num_rows($page_set);
 									//$subject_count+1 because we are adding 1 more subject
 									for($count=1;$count<=$page_count+1;$count++)
 									{
 										echo "<option value=\"{$count}\">{$count}</option>";
 									}
 								?>
 							</select>
 						</p>
 						<p>Visible:
 							<input type="radio" name="visible" value="0"/> No
 							&nbsp;
 							<input type="radio" name="visible" value="1"/> Yes
 						</p>		
 						<p>Content:<br/>
 						<textarea name="content" cols="80" rows="20"><?php echo $sel_page['content'];?></textarea>
 					    </p>
 						<input type="submit" name="submit" value="Create Page"/>	
 
                  </form>	
                  <br />
                  <br />
                  <a href="content.php">Cancel</a>


			</td>
		</tr>				
	</table>	
<?php require("includes/footer.php");?>