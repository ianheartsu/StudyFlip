<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php require_once("includes/form_functions.php");?>
<?php
		if(intval($_GET['page'])==0)
		{
			redirect_to("content.php");
		}

		if(isset($_POST['submit']))
		{
			$errors=array();
			$required_fields=array("menu_name",'position','content');

			//Checking the required fields and visible(also required)

		    $errors=array_merge($errors,check_required_fields($required_fields));



			$fields_with_lengths=array("menu_name" => 30);

			//Checking the maximul field lengths

			$errors=array_merge($errors,check_max_field_lengths($fields_with_lengths));


			if(empty($errors))
			{
				$id=mysql_prep($_GET['page']);
				$menu_name=trim(mysql_prep($_POST['menu_name']));
				$position=mysql_prep($_POST['position']);
				$visible=mysql_prep($_POST['visible']);
				$content=mysql_prep($_POST['content']);

				$query="UPDATE pages SET 
						menu_name='{$menu_name}',
						position={$position},
						visible={$visible},
						content='{$content}'
					WHERE id={$id};";
				$result=mysql_query($query,$connection);	
				if(mysql_affected_rows()==1)
				{
					//Succes
					$message="The page was successfully updated.";
				}
				else 
				{
					//Failure
					$message="The page update failed.";
					$message.="<br/>".mysql_error();
				}

			} 
			else 
			{
				//Errors occured
				if(count($errors)==1){
					$message="There was 1 error in the form.";
				} else {
				$message="There were ".count($errors)." errors in the form.";
				}
			}
		}



?>

<?php 

	find_selected_page(); //and subject

?>
<?php include("includes/header.php"); ?> 
	<table id="structure">
		<tr>
			<td id="navigation">
				<?php echo navigation($sel_subject,$sel_page); ?>	
             	<br />
             	<a href="new_subject.php">+ Add new subject</a>
			</td>
			<td id="page">

				<h2> Edit Page</h2>	
				<?php if(!empty($message)) {echo "<p class=\"message\">".$message."</p>";}?>
				<?php
					if(!empty($errors)) 
					{
						display_errors($errors);
					}
				?>
                  <form action="edit_page.php?page=<?php 
                  echo rawurlencode($sel_page['id']);?>"  method="post">
 						<o>Page name: 
 							<input type="text" name="menu_name" id="menu_name" value="<?php
 							echo $sel_page['menu_name'];?>"/>
 						</p>
 						<p>Position:
 							<select name="position">
 								<?php
 									$page_set=get_pages_for_subject($sel_page['subject_id']);
 									$page_count=mysql_num_rows($page_set);
 									//$subject_count+1 because we are adding 1 more subject
 									for($count=1;$count<=$page_count;$count++)
 									{
 										echo "<option value=\"{$count}\" ";
 										if($count==$sel_page['position'])
 										{
 											echo "selected=\"selected\"";
 										}
 										echo " >{$count}</option>";
 									}
 								?>
 							</select>
 						</p>
 						<p>Visible:
 							<input type="radio" name="visible" value="0" 
 							<?php if($sel_page['visible']==0) echo " checked=\"checked\" "; ?>/> No
 							&nbsp;
 							<input type="radio" name="visible" value="1"
 							<?php if($sel_page['visible']==1) echo " checked=\"checked\" "; ?>/> Yes
 						</p>		
 						<p>Content:<br/>
 						<textarea name="content" cols="80" rows="20"><?php echo $sel_page['content'];?></textarea>
 					    </p>
 						<input type="submit" name="submit" value="Update Page"/>	
 						&nbsp;&nbsp;
 						<a href="delete_page.php?page=<?php echo rawurlencode($sel_page['id'])?>" 
 							onclick="return confirm('Are you sure?');">Delete Page</a>	
 			
 
                  </form>	
                  <br/>
                  <br/>
                  <a href="content.php">Cancel</a>
			</td>
		</tr>				
	</table>	
<?php require("includes/footer.php");?>
