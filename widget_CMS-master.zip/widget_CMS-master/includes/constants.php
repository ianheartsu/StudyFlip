<?php
//Database constants
define("DB_SERVER","localhost");
define("DB_USER","root");
define("DB_PASS","garcea00");
define("DB_NAME","widget_corp");
?>