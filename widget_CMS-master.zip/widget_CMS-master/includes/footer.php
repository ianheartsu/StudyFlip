		</div>	
		<div id="footer">Copyright 2007, Widget Corp</div>
	</body>
</html>	
<?php
  	// 5. Close connection
  	if(isset($connection)){
  		mysql_close($connection);
  	}
?>