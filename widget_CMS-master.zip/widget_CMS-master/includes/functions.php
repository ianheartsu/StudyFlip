<?php 
	//This is the place to store all BASIC functions
		
		function mysql_prep($value){

		$magic_quotes_active=get_magic_quotes_gpc();
		$new_enough_php=function_exists("mysql_real_escape_string");//i.e. PHP>=4.3.0
		if($new_enough_php){
			//if magic quotes are active undo their effect
			if($magic_quotes_active) {$value=stripslashes($value);}
			$value=mysql_real_escape_string($value);
		} else {
			if(!$magic_quotes_active)
			{
				$value=addslashes($value);
			}
		}

		return $value;
	}

	function redirect_to($location=NULL){
		if($location!=NULL){
			header("Location: {$location}");
			exit;
		}
	}

	function confirm_query($result_set)
	{
		if(!$result_set){
			die("Database query failed: ".mysql_error());
		}
	}
	
	function get_all_subjects()
	{
		global $connection;
		$query="SELECT *
			   FROM subjects
			   ORDER BY position ASC";
		$subject_set=mysql_query($query,$connection);
		confirm_query($subject_set);
		return $subject_set;	   
	}

	function get_pages_for_subject($subject_id)
	{  
		global $connection;
		$query="SELECT *
				FROM pages
				WHERE subject_id={$subject_id}
				ORDER BY position ASC";
		$pages_set=mysql_query($query,$connection);
		confirm_query($pages_set);
		return $pages_set;		
	}

	function get_subject_by_id($subject_id){
		global $connection;
		$query="SELECT *";
		$query.=" FROM subjects";
		$query.=" WHERE id=".$subject_id;
		$query.=" LIMIT 1";
		$result_set=mysql_query($query,$connection);
		confirm_query($result_set);
		//If no rows are return my_sql_fetch_array will return false
		if($subject=mysql_fetch_array($result_set)){
			return $subject;
		}
		return NULL;
	}

	function get_page_by_id($page_id){
		global $connection;
		$query="SELECT * ";
		$query.="FROM pages ";
		$query.="WHERE id=".$page_id." ";
		$query.="LIMIT 1";
		$result_set=mysql_query($query,$connection);
		if($page=mysql_fetch_array($result_set)){
			return $page;
		}
		return NULL;
	}

	function find_selected_page(){
		global $sel_subject;
		global $sel_page;
		if(isset($_GET['subj'])){
			$sel_subject=get_subject_by_id($_GET['subj']);
		    $sel_page=NULL; 
		} elseif (isset($_GET['page'])){
			$sel_subject=NULL;
			$sel_page=get_page_by_id($_GET['page']);
		} else{
			$sel_subject=NULL;
			$sel_page=NULL;
		}
	}
	function navigation($sel_subject,$sel_page){

		$output="<ul class=\"subjects\">";	

			// 3. Perform database query

			$subject_set=get_all_subjects();

			// 4. Use returned data
			while($subject=mysql_fetch_array($subject_set)){
				$output.="<li";
				if($subject['id']==$sel_subject['id']){
					$output.=" class=\"selected\"";
				}
			    $output.="><a href=\"edit_subject.php?subj=".rawurlencode($subject["id"]).
				"\">".$subject['menu_name']."</a></li>";
	
				$page_set=get_pages_for_subject($subject['id']);
		
				$output.="<ul class=\"pages\">";
				while($page=mysql_fetch_array($page_set)){
					$output.="<li";
					if($page['id']==$sel_page['id'])
					{
						$output.=" class=\"selected\"";
					}
					$output.="><a href=\"content.php?page=".rawurlencode($page['id']).
                    "\">{$page['menu_name']}</a></li>";
				}	
				$output.="</ul>";
			}
		
     	$output.="</ul>"; 
     	return $output;
	}



?>	