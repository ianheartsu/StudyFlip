<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php 

	find_selected_page(); //and subject

?>
<?php include("includes/header.php"); ?> 
	<table id="structure">
		<tr>
			<td id="navigation">
				<?php echo navigation($sel_subject,$sel_page); ?>	
             	<br />
             	<a href="new_subject.php">+ Add new subject</a>
			</td>
			<td id="page">
				<?php if(!is_null($sel_subject)){      ?>
					<h2><?php echo $sel_subject['menu_name'];?></h2>
				<?php } elseif(!is_null($sel_page)){ ?>
					<h2><?php echo $sel_page['menu_name'];?></h2>
					<div class="page-content">
						<?php echo $sel_page['content'];?>
						</br>
						</br>
						<?php echo "<a href=\"edit_page.php?page=".rawurlencode($sel_page['id'])."\">Edit Page</a>";?>
					</div>
				<?php } else { ?>
                    <h2>Select a subject or page to edit</h2>
			    <?php }  ?>		

			</td>
		</tr>				
	</table>	
<?php require("includes/footer.php");?>
