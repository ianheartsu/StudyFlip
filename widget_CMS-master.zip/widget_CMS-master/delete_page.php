<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>

<?php
	if(intval($_GET['page'])==0)
	{
		redirect_to('content.php');
	}
	$id=mysql_prep($_GET['page']);
	//echo $id;
	if($page=get_page_by_id($id))
	{
		$query="DELETE 
				FROM pages 
				WHERE id={$page['id']}
				LIMIT 1";
		$result=mysql_query($query,$connection);
		if(mysql_affected_rows()==1)
		{
			redirect_to("edit_subject.php?page={$page['id']}");
		}
		else 
		{
			echo "<p>Deletion failed.</p>";
			echo "<p>".mysql_error()."</p>";
			echo "<a href=\"content.php\">Return to main site</a>";
		}			
	}
	else 
	{
		redirect_to("content.php");
	}
?>


<?php
	mysql_close($connection);
?>