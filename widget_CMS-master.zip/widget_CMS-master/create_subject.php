<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php require_once("includes/form_functions.php");?>
<?php
    $errors=array(); //am vazut ca merge si fara
	//Form validation

	$required_fields=array('menu_name','position');

	$errors=array_merge($errors,check_required_fields($required_fields));

	$fields_with_lengths=array('menu_name'=>30);

	$errors=array_merge($errors,check_max_field_lengths($fields_with_lengths));


	if(!empty($errors)){

		// display_errors($errors);
		redirect_to("new_subject.php");
	}
?>
<?php
    $menu_name=trim(mysql_prep($_POST['menu_name']));
    $position=mysql_prep($_POST['position']);
    $visible=mysql_prep($_POST['visible']);
?>
<?php
	$query="INSERT INTO subjects (
		menu_name,position,visible
		) VALUES (
		'{$menu_name}',{$position},{$visible}
		)";
 	if(mysql_query($query,$connection)){
 		//Success!
 		header("Location: content.php");
 		exit;
 	} else {
 		//Display error message
 		echo "<p>Subject creation failed</p>";
 		echo "<p>".mysql_error()."</p>";
 	}
?>
<?php
	 mysql_close($connection);
?>
