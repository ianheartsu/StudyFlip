<?php
  for($i=1;$i<=10;$i++){
  	  $c=$i*2+1;
  }
  //echo $c;
  $a=0;
  $b="";
  if($b==$a){
  	echo  1;
  } else {
  	echo 0;
  }

?>