<?php require_once("includes/connection.php");?>
<?php require_once("includes/functions.php");?>
<?php require_once("includes/form_functions.php")?>
<?php
        if(intval($_GET['subj'])==0){
        	redirect_to("content.php");
        }

		if(isset($_POST['submit']))
		{
			$errors=array();

			//Check required fields 

			$required_fields=array('menu_name','position');
			// foreach($required_fields as $fieldname)
			// {
			// 	//if(!isset($_POST[$fieldname]) || (empty($_POST[$fieldname]) && $_POST[$fieldname]!=0 ) ) NU E BUNA PENTRU
			// 	// CA PICA PENTRU MENU_name="sirul_vid"
			// 	if(!isset($_POST[$fieldname]) || empty($_POST[$fieldname]) )	
			// 	{
			// 		$errors[]=$fieldname;
			// 	}
			// }
			$errors=array_merge(check_required_fields($required_fields));  //Face ambele coduri comentate
			// if(!isset($_POST['visible'])){
			// 	$errors[]='visible';
			// }


			$fields_with_lengths=array('menu_name' => 30);
			$errors=array_merge($errors,check_max_field_lengths($fields_with_lengths));
			// foreach($fields_with_lengths as $fieldname => $maxlength)
			// {
			// 	if(strlen(trim(mysql_prep($_POST[$fieldname])))>$maxlength)
			// 	{
			// 		$errors[]=$fieldname;
			// 	}
			// }
			
			if(empty($errors))
			{
				$id=mysql_prep($_GET['subj']);
				$menu_name=mysql_prep($_POST['menu_name']);
				$position=mysql_prep($_POST['position']);
				$visible=mysql_prep($_POST['visible']);

				$query="UPDATE subjects SET 
						menu_name='{$menu_name}',
						position={$position},
						visible={$visible}
					WHERE id={$id}";
				$result=mysql_query($query,$connection);	
				if(mysql_affected_rows()==1)
				{
					//Success
					$message="The subject was successfully updated";
				}
				else 
				{
					//Failed
					$message="The subject update failed.";
					$message.="<br/>".mysql_error();
				}
				
			}
			else
			{
				//Errors occurred
				$message="There were ".count($errors)." errors in the form.";
			}

		}	

	
?>
<?php 

	find_selected_page(); //and subject

?>
<?php include("includes/header.php"); ?> 
	<table id="structure">
		<tr>
			<td id="navigation">
				<?php	echo navigation($sel_subject,$sel_page);?>
			</td>
			<td id="page">
                  <h2>Edit subject: <?php echo $sel_subject['menu_name'];?></h2>
                  <?php if(! empty($message)) echo "<p class=\"message\">".$message."</p>"; ?>
                  <?php
                  		if(!empty($errors))
                  		{
                  			display_errors($errors);
                  		}	
                  ?>
                  <form action="edit_subject.php?subj=<?php echo rawurlencode($sel_subject['id']);?>"  method="post">
 						<o>Subject name: 
 							<input type="text" name="menu_name" value="<?php echo $sel_subject['menu_name'];?>" id="menu_name"/>
 						</p>
 						<p>Position:
 							<select name="position">
 								<?php
 									$subject_set=get_all_subjects();
 									$subject_count=mysql_num_rows($subject_set);
 									//$subject_count+1 because we are adding 1 more subject
 									for($count=1;$count<=$subject_count;$count++)
 									{
 										echo "<option value=\"{$count}\"";
 										if($sel_subject['position']==$count)
 										{
 											echo " selected=\"selected\" ";
 										}	
 										echo ">{$count}</option>";
 									}
 								?>
 							</select>
 						</p>
 						<p>Visible:
 							<input type="radio" name="visible" value="0" <?php if($sel_subject['visible']==0) 
 							echo " checked=\"checked\" ";?>/> No
 							&nbsp;
 							<input type="radio" name="visible" value="1" <?php if($sel_subject['visible']==1) 
 							echo " checked=\"checked\" ";?>/> Yes
 						</p>			
 						<input type="submit" name="submit" value="Edit Subject"/>
 						&nbsp;&nbsp;	
 						<a href="delete_subject.php?subj=<?php echo rawurlencode($sel_subject['id']); ?>" 
 							onclick="return confirm('Are you sure?');">Delete Subject</a>

                  </form>	
                  <br />
                  <br />
                  <a href="content.php">Cancel</a>
                  <hr/>
                  <h2>Pages in this subject:</h2>
                  <ul>
                  		<?php 
                           $page_set=get_pages_for_subject($sel_subject['id']);
                           while($page=mysql_fetch_array($page_set)){
                           		echo "<li><a href=\"content.php?page=".
                           		rawurlencode($page['id'])."\">".$page['menu_name'].
                           		"</a></li>";
                           }
                  		?>
                  </ul>	
                  <br/>
                  <a href="new_page.php?subj=<?php echo $sel_subject['id'];?>">
                  	+Add a new page to this subject </a>

			</td>
		</tr>				
	</table>	
<?php require("includes/footer.php");?>
